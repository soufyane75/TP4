import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  role: text("role").notNull(), // 'admin' or 'mitarbeiter'
  name: text("name").notNull(),
});

export const articles = pgTable("articles", {
  id: serial("id").primaryKey(),
  articleNumber: text("article_number").notNull().unique(),
  name: text("name").notNull(),
  description: text("description"),
  defaultItemsPerCarton: integer("default_items_per_carton").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const pallets = pgTable("pallets", {
  id: serial("id").primaryKey(),
  palletNumber: text("pallet_number").notNull().unique(), // 128, 90507, 70872
  productDescription: text("product_description").notNull(), // ovale oder rechteckige Flammkuchenrohlinge
  chargeNumber: text("charge_number").notNull(),
  articleNumber: text("article_number").notNull(),
  expiryDate: text("expiry_date").notNull(),
  letterCode: text("letter_code").notNull(), // G, A, M
  cartonCount: integer("carton_count").notNull(),
  itemsPerCarton: integer("items_per_carton").notNull(),
  totalItems: integer("total_items"),
  status: text("status").notNull().default("offen"), // 'offen' or 'abgeschlossen'
  location: text("location"), // 'kühlhaus', 'tiefkühler', 'versandt'
  qrCodeData: text("qr_code_data").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
});

export const insertArticleSchema = createInsertSchema(articles).omit({
  id: true,
  createdAt: true,
}).extend({
  articleNumber: z.string().min(1, "Artikelnummer ist erforderlich"),
  name: z.string().min(1, "Artikelname ist erforderlich"),
  description: z.string().optional(),
  defaultItemsPerCarton: z.number().min(1, "Standard Stückzahl pro Karton muss mindestens 1 sein"),
});

export const updateArticleSchema = z.object({
  articleNumber: z.string().min(1, "Artikelnummer ist erforderlich").optional(),
  name: z.string().min(1, "Artikelname ist erforderlich").optional(),
  description: z.string().optional(),
  defaultItemsPerCarton: z.number().min(1, "Standard Stückzahl pro Karton muss mindestens 1 sein").optional(),
});

export const insertPalletSchema = createInsertSchema(pallets).omit({
  id: true,
  qrCodeData: true,
  createdAt: true,
  totalItems: true,
}).extend({
  palletNumber: z.string().min(1, "Palettennummer ist erforderlich"),
  productDescription: z.string().min(1, "Produktbeschreibung ist erforderlich"),
  chargeNumber: z.string().min(1, "Chargennummer ist erforderlich"),
  articleNumber: z.string().min(1, "Artikelnummer ist erforderlich"),
  expiryDate: z.string().min(1, "MHD ist erforderlich"),
  letterCode: z.enum(["A", "S", "M", "G"], { required_error: "Buchstabe ist erforderlich" }),
  cartonCount: z.number().min(1, "Anzahl Kartons ist erforderlich"),
  itemsPerCarton: z.number().min(1, "Stückzahl pro Karton ist erforderlich"),
});

export const updatePalletSchema = z.object({
  cartonCount: z.number().min(1, "Kartonanzahl muss mindestens 1 sein").optional(),
  itemsPerCarton: z.number().min(1, "Stückzahl pro Karton muss mindestens 1 sein").optional(),
  location: z.enum(["kühlhaus", "tiefkühler", "versandt"]).optional(),
});

export const updateUserSchema = z.object({
  name: z.string().min(1, "Name ist erforderlich").optional(),
  password: z.string().min(4, "Passwort muss mindestens 4 Zeichen lang sein").optional(),
});

export const createUserSchema = z.object({
  username: z.string().min(1, "Benutzername ist erforderlich"),
  password: z.string().min(4, "Passwort muss mindestens 4 Zeichen lang sein"),
  name: z.string().min(1, "Name ist erforderlich"),
  role: z.enum(["admin", "mitarbeiter"], { required_error: "Rolle ist erforderlich" }),
});

export const loginSchema = z.object({
  username: z.string().min(1, "Benutzername ist erforderlich"),
  password: z.string().min(1, "Passwort ist erforderlich"),
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type CreateUser = z.infer<typeof createUserSchema>;
export type UpdateUser = z.infer<typeof updateUserSchema>;
export type InsertArticle = z.infer<typeof insertArticleSchema>;
export type Article = typeof articles.$inferSelect;
export type UpdateArticle = z.infer<typeof updateArticleSchema>;
export type InsertPallet = z.infer<typeof insertPalletSchema>;
export type Pallet = typeof pallets.$inferSelect;
export type UpdatePallet = z.infer<typeof updatePalletSchema>;
export type LoginData = z.infer<typeof loginSchema>;
