import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertArticleSchema, updateArticleSchema, type InsertArticle, type UpdateArticle, type Article } from "@shared/schema";
import { Sidebar } from "@/components/sidebar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { formatDateTime } from "@/lib/utils";
import { Archive, Plus, Package } from "lucide-react";

export default function ArticlesPage() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [editingArticle, setEditingArticle] = useState<Article | null>(null);
  const [deletingArticle, setDeletingArticle] = useState<Article | null>(null);
  const [showCreateForm, setShowCreateForm] = useState(false);

  const { data: articles, isLoading } = useQuery<Article[]>({
    queryKey: ["/api/articles"],
  });

  const form = useForm<InsertArticle>({
    resolver: zodResolver(insertArticleSchema),
    defaultValues: {
      articleNumber: "",
      name: "",
      description: "",
      defaultItemsPerCarton: 1,
    },
  });

  const editForm = useForm<UpdateArticle>({
    resolver: zodResolver(updateArticleSchema),
    defaultValues: {
      articleNumber: "",
      name: "",
      description: "",
      defaultItemsPerCarton: 1,
    },
  });

  const createMutation = useMutation({
    mutationFn: async (data: InsertArticle) => {
      const response = await apiRequest("POST", "/api/articles", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/articles"] });
      toast({
        title: "Artikel erfolgreich erstellt",
        description: "Der neue Artikel wurde zur Datenbank hinzugefügt",
      });
      form.reset();
      setShowCreateForm(false);
    },
    onError: (error: any) => {
      toast({
        title: "Fehler beim Erstellen",
        description: error.message || "Unbekannter Fehler",
        variant: "destructive",
      });
    },
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: UpdateArticle }) => {
      const response = await apiRequest("PATCH", `/api/articles/${id}`, data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/articles"] });
      toast({
        title: "Artikel aktualisiert",
        description: "Der Artikel wurde erfolgreich aktualisiert.",
      });
      setEditingArticle(null);
      editForm.reset();
    },
    onError: () => {
      toast({
        title: "Fehler",
        description: "Fehler beim Aktualisieren des Artikels.",
        variant: "destructive",
      });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      const response = await apiRequest("DELETE", `/api/articles/${id}`);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/articles"] });
      toast({
        title: "Artikel gelöscht",
        description: "Der Artikel wurde erfolgreich gelöscht.",
      });
      setDeletingArticle(null);
    },
    onError: () => {
      toast({
        title: "Fehler",
        description: "Fehler beim Löschen des Artikels.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = async (data: InsertArticle) => {
    await createMutation.mutateAsync(data);
  };

  const onEditSubmit = async (data: UpdateArticle) => {
    if (editingArticle) {
      updateMutation.mutate({ id: editingArticle.id, data });
    }
  };

  const handleEdit = (article: Article) => {
    setEditingArticle(article);
    editForm.reset({
      articleNumber: article.articleNumber,
      name: article.name,
      description: article.description || "",
      defaultItemsPerCarton: article.defaultItemsPerCarton,
    });
  };

  const handleDelete = (article: Article) => {
    setDeletingArticle(article);
  };

  const confirmDelete = () => {
    if (deletingArticle) {
      deleteMutation.mutate(deletingArticle.id);
    }
  };

  const handleCancel = () => {
    form.reset();
    setShowCreateForm(false);
  };

  return (
    <div className="flex h-screen bg-neutral-50">
      <Sidebar />
      
      <main className="flex-1 overflow-auto">
        <div className="max-w-6xl mx-auto p-6 space-y-6">
          {/* Header */}
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Archive className="text-primary text-2xl" />
              <div>
                <h1 className="text-2xl font-semibold text-neutral-900">Artikel verwalten</h1>
                <p className="text-neutral-600">Erstellen und verwalten Sie Artikel für die Palettenproduktion</p>
              </div>
            </div>
            <Button
              onClick={() => setShowCreateForm(!showCreateForm)}
              className="text-lg min-h-[48px]"
              size="lg"
            >
              <Plus className="mr-2 h-5 w-5" />
              Neuen Artikel erstellen
            </Button>
          </div>

          {/* Create Form */}
          {showCreateForm && (
            <Card>
              <CardHeader>
                <CardTitle>Neuen Artikel erstellen</CardTitle>
              </CardHeader>
              <CardContent>
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <FormField
                        control={form.control}
                        name="articleNumber"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Artikelnummer</FormLabel>
                            <FormControl>
                              <Input
                                {...field}
                                placeholder="z.B. 1025"
                                className="text-lg py-3"
                                disabled={createMutation.isPending}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="name"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Artikelname</FormLabel>
                            <FormControl>
                              <Input
                                {...field}
                                placeholder="z.B. Flammkuchen XL"
                                className="text-lg py-3"
                                disabled={createMutation.isPending}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <FormField
                      control={form.control}
                      name="description"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Beschreibung (optional)</FormLabel>
                          <FormControl>
                            <Textarea
                              {...field}
                              placeholder="Zusätzliche Informationen zum Artikel..."
                              className="min-h-[100px]"
                              disabled={createMutation.isPending}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="defaultItemsPerCarton"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Standard Stückzahl pro Karton</FormLabel>
                          <FormControl>
                            <Input
                              type="number"
                              min="1"
                              placeholder="z.B. 12"
                              className="text-lg py-3"
                              disabled={createMutation.isPending}
                              onChange={(e) => field.onChange(parseInt(e.target.value) || 1)}
                              value={field.value || 1}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <div className="flex flex-col sm:flex-row gap-4 pt-4">
                      <Button
                        type="submit"
                        className="flex-1 text-lg min-h-[48px]"
                        disabled={createMutation.isPending}
                      >
                        {createMutation.isPending ? "Erstellen..." : "Artikel erstellen"}
                      </Button>

                      <Button
                        type="button"
                        variant="secondary"
                        onClick={handleCancel}
                        className="flex-1 text-lg min-h-[48px]"
                        disabled={createMutation.isPending}
                      >
                        Abbrechen
                      </Button>
                    </div>
                  </form>
                </Form>
              </CardContent>
            </Card>
          )}

          {/* Articles List */}
          <Card>
            <CardHeader>
              <CardTitle>Alle Artikel</CardTitle>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="text-center py-8">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
                  <p className="text-neutral-600">Artikel werden geladen...</p>
                </div>
              ) : articles?.length === 0 ? (
                <div className="text-center py-8">
                  <Package className="mx-auto h-12 w-12 text-neutral-400 mb-4" />
                  <h3 className="text-lg font-medium text-neutral-900 mb-2">Keine Artikel vorhanden</h3>
                  <p className="text-neutral-600">Erstellen Sie Ihren ersten Artikel, um zu beginnen.</p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="bg-neutral-50">
                      <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                          Artikelnummer
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                          Name
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                          Beschreibung
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                          Standard Stückzahl
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                          Aktionen
                        </th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-neutral-200">
                      {articles?.map((article) => (
                        <tr key={article.id} className="hover:bg-neutral-50">
                          <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-neutral-900">
                            {article.articleNumber}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="text-sm font-medium text-neutral-900">{article.name}</div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-500">
                            {article.description || "—"}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-900">
                            {article.defaultItemsPerCarton}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-500">
                            <div className="flex space-x-2">
                              <Button 
                                variant="outline" 
                                size="sm"
                                onClick={() => handleEdit(article)}
                                disabled={updateMutation.isPending}
                              >
                                Bearbeiten
                              </Button>
                              <Button 
                                variant="outline" 
                                size="sm" 
                                className="text-red-600 hover:text-red-700"
                                onClick={() => handleDelete(article)}
                                disabled={deleteMutation.isPending}
                              >
                                Löschen
                              </Button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </main>

      {/* Edit Article Dialog */}
      <Dialog open={editingArticle !== null} onOpenChange={(open) => !open && setEditingArticle(null)}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Artikel bearbeiten</DialogTitle>
            <DialogDescription>
              Bearbeiten Sie die Artikeldetails und speichern Sie die Änderungen.
            </DialogDescription>
          </DialogHeader>
          <Form {...editForm}>
            <form onSubmit={editForm.handleSubmit(onEditSubmit)} className="space-y-4">
              <FormField
                control={editForm.control}
                name="articleNumber"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Artikelnummer</FormLabel>
                    <FormControl>
                      <Input
                        {...field}
                        placeholder="z.B. 1025"
                        disabled={updateMutation.isPending}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={editForm.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Artikelname</FormLabel>
                    <FormControl>
                      <Input
                        {...field}
                        placeholder="z.B. Flammkuchen XL"
                        disabled={updateMutation.isPending}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={editForm.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Beschreibung</FormLabel>
                    <FormControl>
                      <Textarea
                        {...field}
                        placeholder="Optionale Beschreibung des Artikels"
                        disabled={updateMutation.isPending}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={editForm.control}
                name="defaultItemsPerCarton"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Standard Stückzahl pro Karton</FormLabel>
                    <FormControl>
                      <Input
                        {...field}
                        type="number"
                        min="1"
                        onChange={(e) => field.onChange(parseInt(e.target.value) || 1)}
                        disabled={updateMutation.isPending}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="flex justify-end space-x-2 pt-4">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setEditingArticle(null)}
                  disabled={updateMutation.isPending}
                >
                  Abbrechen
                </Button>
                <Button type="submit" disabled={updateMutation.isPending}>
                  {updateMutation.isPending ? "Wird gespeichert..." : "Speichern"}
                </Button>
              </div>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Delete Article Confirmation */}
      <AlertDialog open={deletingArticle !== null} onOpenChange={(open) => !open && setDeletingArticle(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Artikel löschen</AlertDialogTitle>
            <AlertDialogDescription>
              Sind Sie sicher, dass Sie den Artikel "{deletingArticle?.name}" löschen möchten? 
              Diese Aktion kann nicht rückgängig gemacht werden.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={deleteMutation.isPending}>
              Abbrechen
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={confirmDelete}
              disabled={deleteMutation.isPending}
              className="bg-red-600 hover:bg-red-700"
            >
              {deleteMutation.isPending ? "Wird gelöscht..." : "Löschen"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}