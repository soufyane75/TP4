import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Sidebar } from "@/components/sidebar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { CheckCircle, Package, Truck, Snowflake, Thermometer, Download, FileText } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { formatDate } from "@/lib/utils";
import { exportCompletedPalletsToPDF, exportSinglePalletToPDF, type PalletData } from "@/lib/pdf-export";
import { type Pallet } from "@shared/schema";

export default function CompletedPalletsPage() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: pallets, isLoading } = useQuery({
    queryKey: ["/api/pallets/completed"],
    queryFn: async () => {
      const response = await apiRequest("GET", "/api/pallets/completed");
      return response.json() as Promise<Pallet[]>;
    },
  });

  const updateLocationMutation = useMutation({
    mutationFn: async ({ id, location }: { id: number; location: string }) => {
      const response = await apiRequest("PATCH", `/api/pallets/${id}`, { location });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/pallets/completed"] });
      toast({
        title: "Standort aktualisiert",
        description: "Der Palette-Standort wurde erfolgreich geändert",
      });
    },
    onError: () => {
      toast({
        title: "Fehler",
        description: "Standort konnte nicht aktualisiert werden",
        variant: "destructive",
      });
    },
  });

  const getLocationIcon = (location: string | null) => {
    switch (location) {
      case "kühlhaus":
        return <Thermometer className="h-4 w-4" />;
      case "tiefkühler":
        return <Snowflake className="h-4 w-4" />;
      case "versandt":
        return <Truck className="h-4 w-4" />;
      default:
        return <Package className="h-4 w-4" />;
    }
  };

  const getLocationBadge = (location: string | null) => {
    if (!location) {
      return <Badge variant="outline">Nicht zugewiesen</Badge>;
    }

    const variants: Record<string, any> = {
      kühlhaus: "secondary",
      tiefkühler: "default",
      versandt: "success",
    };

    return (
      <Badge variant={variants[location] || "outline"} className="flex items-center gap-1">
        {getLocationIcon(location)}
        {location === "kühlhaus" && "Kühlhaus"}
        {location === "tiefkühler" && "Tiefkühler"}
        {location === "versandt" && "Versandt"}
        {!["kühlhaus", "tiefkühler", "versandt"].includes(location) && location}
      </Badge>
    );
  };

  const handleLocationChange = (palletId: number, newLocation: string) => {
    updateLocationMutation.mutate({ id: palletId, location: newLocation });
  };

  const handleExportAll = () => {
    if (!pallets || pallets.length === 0) {
      toast({
        title: "Keine Daten zum Exportieren",
        description: "Es sind keine abgeschlossenen Paletten vorhanden",
        variant: "destructive",
      });
      return;
    }

    try {
      exportCompletedPalletsToPDF(pallets);
      toast({
        title: "Export erfolgreich",
        description: `${pallets.length} Paletten wurden als PDF exportiert`,
      });
    } catch (error) {
      toast({
        title: "Export fehlgeschlagen",
        description: "Fehler beim Erstellen des PDF-Exports",
        variant: "destructive",
      });
    }
  };

  const handleExportSingle = (pallet: Pallet) => {
    try {
      exportSinglePalletToPDF(pallet);
      toast({
        title: "Export erfolgreich",
        description: `Palette ${pallet.palletNumber} wurde als PDF exportiert`,
      });
    } catch (error) {
      toast({
        title: "Export fehlgeschlagen",
        description: "Fehler beim Erstellen des PDF-Exports",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="flex h-screen bg-neutral-50">
      <Sidebar />
      
      <main className="flex-1 overflow-auto">
        <div className="max-w-7xl mx-auto p-6 space-y-6">
          <div className="mb-8">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 bg-success/10 rounded-lg flex items-center justify-center">
                <CheckCircle className="h-6 w-6 text-success" />
              </div>
              <div>
                <h1 className="text-3xl font-bold text-neutral-900">Abgeschlossene Paletten</h1>
                <p className="text-neutral-600">Verwalten Sie fertige Paletten und deren Standorte</p>
              </div>
            </div>
          </div>

          <Card>
            <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>Alle abgeschlossenen Paletten</CardTitle>
              <Button
                onClick={handleExportAll}
                disabled={!pallets || pallets.length === 0}
                className="bg-primary hover:bg-primary-dark"
              >
                <Download className="mr-2 h-4 w-4" />
                Alle als PDF exportieren
              </Button>
            </div>
          </CardHeader>
          
          <CardContent>
            {isLoading ? (
              <div className="text-center py-8">
                <p className="text-neutral-500">Lädt Paletten...</p>
              </div>
            ) : pallets?.length === 0 ? (
              <div className="text-center py-8">
                <Package className="mx-auto h-12 w-12 text-neutral-400 mb-4" />
                <p className="text-neutral-500">Keine abgeschlossenen Paletten vorhanden</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-neutral-50">
                    <tr>
                      <th className="px-4 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                        Paletten-Nr.
                      </th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                        Produktbeschreibung
                      </th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                        Buchstabe
                      </th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                        MHD
                      </th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                        Gesamtstück
                      </th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                        Standort
                      </th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                        Abgeschlossen am
                      </th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                        Aktionen
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-neutral-200">
                    {pallets?.map((pallet) => (
                      <tr key={pallet.id}>
                        <td className="px-4 py-4 whitespace-nowrap text-sm font-mono text-neutral-900">
                          {pallet.palletNumber}
                        </td>
                        <td className="px-4 py-4 whitespace-nowrap text-sm text-neutral-900">
                          {pallet.productDescription}
                        </td>
                        <td className="px-4 py-4 whitespace-nowrap text-sm text-neutral-900">
                          {pallet.letterCode}
                        </td>
                        <td className="px-4 py-4 whitespace-nowrap text-sm text-neutral-900">
                          {pallet.expiryDate}
                        </td>
                        <td className="px-4 py-4 whitespace-nowrap text-sm text-neutral-900">
                          {pallet.totalItems} Stück
                        </td>
                        <td className="px-4 py-4 whitespace-nowrap">
                          {getLocationBadge(pallet.location)}
                        </td>
                        <td className="px-4 py-4 whitespace-nowrap text-sm text-neutral-500">
                          {formatDate(pallet.createdAt)}
                        </td>
                        <td className="px-4 py-4 whitespace-nowrap">
                          <div className="flex gap-2">
                            <Select
                              value={pallet.location || ""}
                              onValueChange={(value) => handleLocationChange(pallet.id, value)}
                              disabled={updateLocationMutation.isPending}
                            >
                              <SelectTrigger className="w-32">
                                <SelectValue placeholder="Standort" />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="kühlhaus">Kühlhaus</SelectItem>
                                <SelectItem value="tiefkühler">Tiefkühler</SelectItem>
                                <SelectItem value="versandt">Versandt</SelectItem>
                              </SelectContent>
                            </Select>
                            
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleExportSingle(pallet)}
                              className="text-primary hover:text-primary-dark"
                            >
                              <FileText className="h-4 w-4" />
                            </Button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>
        </div>
      </main>
    </div>
  );
}