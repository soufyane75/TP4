import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertPalletSchema, type InsertPallet, type Article } from "@shared/schema";
import { Sidebar } from "@/components/sidebar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { useLocation } from "wouter";
import { Plus, Package, Info } from "lucide-react";

export default function CreatePalletPage() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [, setLocation] = useLocation();

  const { data: articles } = useQuery<Article[]>({
    queryKey: ["/api/articles"],
  });

  const form = useForm<InsertPallet>({
    resolver: zodResolver(insertPalletSchema),
    defaultValues: {
      palletNumber: "",
      productDescription: "",
      chargeNumber: "",
      articleNumber: "",
      expiryDate: "",
      letterCode: "G",
      cartonCount: 1,
      itemsPerCarton: 1,
    },
  });

  const createMutation = useMutation({
    mutationFn: async (data: InsertPallet) => {
      const response = await apiRequest("POST", "/api/pallets", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/pallets"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
      toast({
        title: "Palette erfolgreich erstellt",
        description: "Die neue Palette wurde angelegt und der QR-Code generiert",
      });
      form.reset();
      setLocation("/admin");
    },
    onError: (error: any) => {
      toast({
        title: "Fehler beim Erstellen",
        description: error.message || "Unbekannter Fehler",
        variant: "destructive",
      });
    },
  });

  const onSubmit = async (data: InsertPallet) => {
    await createMutation.mutateAsync(data);
  };

  const handleCancel = () => {
    setLocation("/admin");
  };

  const handleArticleSelect = (articleId: string) => {
    const article = articles?.find(a => a.id.toString() === articleId);
    if (article) {
      form.setValue("articleNumber", article.articleNumber);
      form.setValue("productDescription", article.description || article.name);
      if (article.defaultItemsPerCarton) {
        form.setValue("itemsPerCarton", article.defaultItemsPerCarton);
      }
    }
  };

  return (
    <div className="flex h-screen bg-neutral-50">
      <Sidebar />
      
      <main className="flex-1 overflow-auto">
        <div className="max-w-4xl mx-auto p-6 space-y-6">
          {/* Header */}
          <div className="flex items-center space-x-3">
            <Plus className="text-primary text-2xl" />
            <div>
              <h1 className="text-2xl font-semibold text-neutral-900">Neue Palette erstellen</h1>
              <p className="text-neutral-600">Erstellen Sie eine neue Palette für die Produktion</p>
            </div>
          </div>

          {/* Create Form */}
          <Card>
            <CardHeader>
              <CardTitle>Paletten-Details</CardTitle>
            </CardHeader>
            <CardContent>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                  {/* Optional Article Selection for Auto-Fill */}
                  <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                    <h4 className="text-sm font-medium text-blue-900 mb-3">Artikel auswählen (optional)</h4>
                    <p className="text-sm text-blue-700 mb-3">Wählen Sie einen gespeicherten Artikel aus, um die Felder automatisch zu füllen</p>
                    <Select onValueChange={handleArticleSelect}>
                      <SelectTrigger className="w-full">
                        <SelectValue placeholder="Artikel für Auto-Fill auswählen" />
                      </SelectTrigger>
                      <SelectContent>
                        {articles?.map((article) => (
                          <SelectItem key={article.id} value={article.id.toString()}>
                            {article.articleNumber} - {article.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <FormField
                      control={form.control}
                      name="palletNumber"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Palettennummer</FormLabel>
                          <FormControl>
                            <Input
                              {...field}
                              placeholder="z.B. 128, 90507, 70872"
                              className="text-lg py-3"
                              disabled={createMutation.isPending}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="articleNumber"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Artikelnummer</FormLabel>
                          <FormControl>
                            <Input
                              {...field}
                              placeholder="z.B. 1025"
                              className="text-lg py-3"
                              disabled={createMutation.isPending}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <FormField
                    control={form.control}
                    name="productDescription"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Produktbeschreibung</FormLabel>
                        <FormControl>
                          <Input
                            {...field}
                            placeholder="z.B. ovale oder rechteckige Flammkuchenrohlinge"
                            className="text-lg py-3"
                            disabled={createMutation.isPending}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <FormField
                      control={form.control}
                      name="chargeNumber"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Charge</FormLabel>
                          <FormControl>
                            <Input
                              {...field}
                              placeholder="z.B. CH-240604-001"
                              className="text-lg py-3"
                              disabled={createMutation.isPending}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="letterCode"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Buchstabe *</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger className="text-lg py-3">
                                <SelectValue placeholder="Wählen Sie A, S, M oder G" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="A">A</SelectItem>
                              <SelectItem value="S">S</SelectItem>
                              <SelectItem value="M">M</SelectItem>
                              <SelectItem value="G">G</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="expiryDate"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>MHD</FormLabel>
                          <FormControl>
                            <Input
                              {...field}
                              type="date"
                              className="text-lg py-3"
                              disabled={createMutation.isPending}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <FormField
                      control={form.control}
                      name="cartonCount"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Kartonanzahl</FormLabel>
                          <FormControl>
                            <Input
                              {...field}
                              type="number"
                              min="1"
                              placeholder="z.B. 50"
                              className="text-lg py-3"
                              onChange={(e) => field.onChange(parseInt(e.target.value) || 1)}
                              disabled={createMutation.isPending}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="itemsPerCarton"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Stückzahl pro Karton</FormLabel>
                          <FormControl>
                            <Input
                              {...field}
                              type="number"
                              min="1"
                              placeholder="z.B. 10"
                              className="text-lg py-3"
                              onChange={(e) => field.onChange(parseInt(e.target.value) || 1)}
                              disabled={createMutation.isPending}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <div className="flex flex-col sm:flex-row gap-4 pt-6">
                    <Button
                      type="submit"
                      className="flex-1 text-lg min-h-[48px]"
                      disabled={createMutation.isPending}
                    >
                      {createMutation.isPending ? "Erstellen..." : "Palette erstellen"}
                    </Button>

                    <Button
                      type="button"
                      variant="secondary"
                      onClick={handleCancel}
                      className="flex-1 text-lg min-h-[48px]"
                      disabled={createMutation.isPending}
                    >
                      Abbrechen
                    </Button>
                  </div>
                </form>
              </Form>
            </CardContent>
          </Card>

          {/* Help Section */}
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-start space-x-3">
                <Package className="text-neutral-400 mt-1" size={20} />
                <div>
                  <h3 className="text-sm font-medium text-neutral-900">Hinweise zur Palettenerstellung</h3>
                  <ul className="text-sm text-neutral-600 mt-2 space-y-1">
                    <li>• Nach der Erstellung wird automatisch ein QR-Code generiert</li>
                    <li>• Mitarbeiter können den QR-Code scannen, um Karton- und Stückzahlen hinzuzufügen</li>
                    <li>• Die Palette wird automatisch als "abgeschlossen" markiert, wenn alle Daten eingegeben sind</li>
                    <li>• Artikel können optional zugeordnet werden für bessere Nachverfolgung</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}