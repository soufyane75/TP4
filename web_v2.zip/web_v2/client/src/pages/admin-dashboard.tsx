import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Sidebar } from "@/components/sidebar";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { QRCodeModal } from "@/components/qr-code-modal";
import { Home, Clock, CheckCircle, PlusCircle, Download, QrCode, Package, AlertTriangle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Link } from "wouter";
import type { Pallet } from "@shared/schema";

interface Stats {
  openPallets: number;
  completedPallets: number;
  todayCreated: number;
}

export default function AdminDashboard() {
  const { toast } = useToast();
  const [qrModalOpen, setQrModalOpen] = useState(false);
  const [selectedPallet, setSelectedPallet] = useState<Pallet | null>(null);

  const { data: stats, isLoading: statsLoading } = useQuery<Stats>({
    queryKey: ["/api/stats"],
  });

  const { data: pallets, isLoading: palletsLoading } = useQuery<Pallet[]>({
    queryKey: ["/api/pallets"],
  });

  const { data: expiringPallets = [] } = useQuery<Pallet[]>({
    queryKey: ["/api/pallets/expiry-alerts"],
  });

  const getCriticalCount = () => {
    const today = new Date();
    return expiringPallets.filter(pallet => {
      const expiry = new Date(pallet.expiryDate);
      const diffTime = expiry.getTime() - today.getTime();
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      return diffDays <= 30;
    }).length;
  };

  const criticalCount = getCriticalCount();

  const handleExport = async () => {
    try {
      // In a real implementation, this would generate and download a PDF
      toast({
        title: "Export wird vorbereitet",
        description: "Die abgeschlossenen Paletten werden exportiert...",
      });
    } catch (error) {
      toast({
        title: "Export fehlgeschlagen",
        description: "Fehler beim Exportieren der Paletten",
        variant: "destructive",
      });
    }
  };

  const handleQRShow = (pallet: Pallet) => {
    setSelectedPallet(pallet);
    setQrModalOpen(true);
  };

  const getStatusBadge = (status: string) => {
    if (status === "abgeschlossen") {
      return <span className="px-3 py-1 text-xs font-medium rounded-full bg-success text-white">Abgeschlossen</span>;
    }
    return <span className="px-3 py-1 text-xs font-medium rounded-full bg-warning text-white">Offen</span>;
  };

  return (
    <div className="flex h-screen bg-neutral-50">
      <Sidebar />
      
      <main className="flex-1 overflow-auto">
        <div className="max-w-6xl mx-auto p-6 space-y-6">
          {/* Header */}
          <div className="flex items-center space-x-3">
            <Home className="text-primary text-2xl" />
            <div>
              <h1 className="text-2xl font-semibold text-neutral-900">Admin Dashboard</h1>
              <p className="text-neutral-600">Übersicht über alle Paletten und Statistiken</p>
            </div>
          </div>
          {/* Stats Overview */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-neutral-600">Offene Paletten</p>
                    <p className="text-3xl font-semibold text-primary">
                      {statsLoading ? "..." : stats?.openPallets || 0}
                    </p>
                  </div>
                  <Clock className="text-warning text-2xl" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-neutral-600">Abgeschlossen</p>
                    <p className="text-3xl font-semibold text-secondary">
                      {statsLoading ? "..." : stats?.completedPallets || 0}
                    </p>
                  </div>
                  <CheckCircle className="text-success text-2xl" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-neutral-600">Heute erstellt</p>
                    <p className="text-3xl font-semibold text-neutral-800">
                      {statsLoading ? "..." : stats?.todayCreated || 0}
                    </p>
                  </div>
                  <PlusCircle className="text-primary text-2xl" />
                </div>
              </CardContent>
            </Card>

            <Card className={criticalCount > 0 ? "border-red-200 bg-red-50" : ""}>
              <CardContent className="p-6">
                <Link href="/expiry-alerts" className="block">
                  <div className="flex items-center justify-between cursor-pointer">
                    <div>
                      <p className="text-sm text-neutral-600">MHD-Alarme</p>
                      <p className={`text-3xl font-semibold ${criticalCount > 0 ? "text-red-600" : "text-green-600"}`}>
                        {criticalCount}
                      </p>
                      <p className="text-xs text-neutral-500 mt-1">
                        {criticalCount > 0 ? "Kritische Warnungen" : "Keine Alarme"}
                      </p>
                    </div>
                    <AlertTriangle className={`text-2xl ${criticalCount > 0 ? "text-red-500" : "text-green-500"}`} />
                  </div>
                </Link>
              </CardContent>
            </Card>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row gap-4">
            <Link href="/create-pallet">
              <Button
                className="text-lg min-h-[48px] bg-primary hover:bg-primary-dark w-full"
                size="lg"
              >
                <PlusCircle className="mr-2 h-5 w-5" />
                Neue Palette erstellen
              </Button>
            </Link>

            <Button
              onClick={handleExport}
              variant="secondary"
              className="text-lg min-h-[48px] bg-secondary hover:bg-green-700 text-white"
              size="lg"
            >
              <Download className="mr-2 h-5 w-5" />
              Abgeschlossene exportieren
            </Button>
          </div>

          {/* Pallets Table */}
          <Card>
            <div className="px-6 py-4 border-b border-neutral-200">
              <h3 className="text-lg font-semibold text-neutral-900">Alle Paletten</h3>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-neutral-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                      Paletten-Nr.
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                      Buchstabe
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                      MHD
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                      Status
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                      QR Code
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-neutral-200">
                  {palletsLoading ? (
                    <tr>
                      <td colSpan={5} className="px-6 py-4 text-center text-neutral-500">
                        Lädt Paletten...
                      </td>
                    </tr>
                  ) : pallets?.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="px-6 py-4 text-center text-neutral-500">
                        Keine Paletten vorhanden
                      </td>
                    </tr>
                  ) : (
                    pallets?.map((pallet) => (
                      <tr key={pallet.id}>
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-mono text-neutral-900">
                          {pallet.palletNumber}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-900">
                          {pallet.letterCode}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-900">
                          {pallet.expiryDate}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          {getStatusBadge(pallet.status)}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleQRShow(pallet)}
                            className="text-primary hover:text-primary-dark"
                          >
                            <QrCode className="h-5 w-5" />
                          </Button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </Card>
        </div>
      </main>

      <QRCodeModal
        open={qrModalOpen}
        onOpenChange={setQrModalOpen}
        pallet={selectedPallet}
      />
    </div>
  );
}
