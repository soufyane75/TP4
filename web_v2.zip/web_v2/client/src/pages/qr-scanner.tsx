import { useState, useRef, useEffect } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Camera, X, ScanLine, Search } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Sidebar } from "@/components/sidebar";

export default function QRScannerPage() {
  const [isScanning, setIsScanning] = useState(false);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [manualCode, setManualCode] = useState("");
  const [cameraError, setCameraError] = useState("");
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const startCamera = async () => {
    setCameraError("");
    
    try {
      // Check if camera is supported
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        setCameraError("Kamera wird von diesem Browser nicht unterstützt");
        return;
      }

      // Request camera permission with fallback options
      let mediaStream;
      try {
        // Try back camera first (ideal for QR scanning)
        mediaStream = await navigator.mediaDevices.getUserMedia({
          video: { 
            facingMode: "environment",
            width: { ideal: 1280 },
            height: { ideal: 720 }
          }
        });
      } catch {
        // Fallback to any available camera
        mediaStream = await navigator.mediaDevices.getUserMedia({
          video: {
            width: { ideal: 1280 },
            height: { ideal: 720 }
          }
        });
      }
      
      if (videoRef.current && mediaStream) {
        videoRef.current.srcObject = mediaStream;
        setStream(mediaStream);
        setIsScanning(true);
        
        // Wait for video to load
        videoRef.current.onloadedmetadata = () => {
          videoRef.current?.play();
        };
      }
    } catch (error: any) {
      let errorMessage = "Kamera konnte nicht geöffnet werden.";
      
      if (error.name === "NotAllowedError") {
        errorMessage = "Kamera-Zugriff wurde verweigert. Bitte erlauben Sie den Kamera-Zugriff in den Browser-Einstellungen.";
      } else if (error.name === "NotFoundError") {
        errorMessage = "Keine Kamera gefunden. Bitte verwenden Sie die manuelle Eingabe.";
      } else if (error.name === "NotReadableError") {
        errorMessage = "Kamera wird bereits von einer anderen Anwendung verwendet.";
      }
      
      setCameraError(errorMessage);
      toast({
        title: "Kamera-Fehler",
        description: errorMessage,
        variant: "destructive",
      });
    }
  };

  const stopCamera = () => {
    if (stream) {
      stream.getTracks().forEach(track => track.stop());
      setStream(null);
    }
    setIsScanning(false);
  };

  const captureAndScan = () => {
    if (videoRef.current && canvasRef.current) {
      const canvas = canvasRef.current;
      const video = videoRef.current;
      const context = canvas.getContext("2d");
      
      if (context) {
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        context.drawImage(video, 0, 0);
        
        // Simulate QR code scanning with enhanced feedback
        toast({
          title: "QR-Code erfasst",
          description: "QR-Code Bibliothek wird benötigt für automatische Erkennung. Verwenden Sie die manuelle Eingabe für jetzt.",
        });
        
        // Stop camera after capture attempt
        stopCamera();
      }
    }
  };

  const processQRData = (qrContent: string) => {
    try {
      // Try to parse as JSON first (new comprehensive format)
      const qrData = JSON.parse(qrContent);
      
      if (qrData.type === "pallet" && qrData.palletNumber) {
        toast({
          title: "QR-Code dekodiert",
          description: `Palette ${qrData.palletNumber} gefunden - ${qrData.productDescription || 'Keine Beschreibung'}`,
        });
        setLocation(`/pallet/${qrData.palletNumber}`);
        return;
      }
    } catch {
      // Fallback: treat as simple pallet number or URL
      if (qrContent.includes('/pallet/')) {
        const palletNumber = qrContent.split('/pallet/')[1];
        setLocation(`/pallet/${palletNumber}`);
        return;
      }
      
      // Treat as direct pallet number
      setLocation(`/pallet/${qrContent}`);
    }
  };

  const handleManualSearch = async () => {
    if (!manualCode.trim()) {
      toast({
        title: "Eingabe erforderlich",
        description: "Bitte geben Sie eine Paletten-Nummer ein",
        variant: "destructive",
      });
      return;
    }

    try {
      setLocation(`/pallet/${manualCode.trim()}`);
    } catch (error) {
      toast({
        title: "Fehler",
        description: "Fehler beim Suchen der Palette",
        variant: "destructive",
      });
    }
  };

  const handleBackToDashboard = () => {
    setLocation("/dashboard");
  };

  useEffect(() => {
    return () => {
      stopCamera();
    };
  }, []);

  return (
    <div className="flex h-screen bg-neutral-50">
      <Sidebar />
      
      <main className="flex-1 overflow-auto">
        <div className="max-w-4xl mx-auto p-6">
          <Card>
            <CardHeader className="text-center">
              <div className="mx-auto w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mb-4">
                <ScanLine className="h-8 w-8 text-primary" />
              </div>
              <CardTitle className="text-2xl">QR-Code Scanner</CardTitle>
              <p className="text-neutral-600">
                Scannen Sie den QR-Code auf der Palette, um sie zu bearbeiten
              </p>
            </CardHeader>

            <CardContent className="space-y-6">
              {/* Camera Section */}
              {!isScanning ? (
                <div className="text-center space-y-4">
                  {cameraError ? (
                    <div className="mx-auto w-32 h-32 bg-red-50 rounded-lg flex items-center justify-center">
                      <X className="h-12 w-12 text-red-400" />
                    </div>
                  ) : (
                    <div className="mx-auto w-32 h-32 bg-neutral-100 rounded-lg flex items-center justify-center">
                      <Camera className="h-12 w-12 text-neutral-400" />
                    </div>
                  )}
                  
                  {cameraError && (
                    <div className="bg-red-50 border border-red-200 rounded-lg p-4 text-red-700 text-sm">
                      {cameraError}
                    </div>
                  )}
                  
                  <Button 
                    onClick={startCamera}
                    size="lg"
                    className="w-full"
                    disabled={!!cameraError && cameraError.includes("nicht unterstützt")}
                  >
                    <Camera className="mr-2 h-5 w-5" />
                    QR-Code Scanner öffnen
                  </Button>
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="relative">
                    <video
                      ref={videoRef}
                      autoPlay
                      playsInline
                      muted
                      className="w-full rounded-lg bg-black"
                      style={{ maxHeight: "400px", objectFit: "cover" }}
                    />
                    <div className="absolute inset-0 border-2 border-primary rounded-lg pointer-events-none">
                      <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-48 h-48 border-2 border-white rounded-lg bg-white/10"></div>
                    </div>
                  </div>

                  <canvas ref={canvasRef} className="hidden" />

                  <div className="flex gap-3">
                    <Button 
                      onClick={captureAndScan}
                      className="flex-1"
                    >
                      <ScanLine className="mr-2 h-4 w-4" />
                      Scannen
                    </Button>
                    
                    <Button 
                      onClick={stopCamera}
                      variant="outline"
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              )}

              {/* Manual Input Section */}
              <div className="border-t pt-6">
                <div className="space-y-4">
                  <div className="text-center">
                    <h3 className="text-lg font-medium text-neutral-900 mb-2">
                      Manuelle Paletten-Suche
                    </h3>
                    <p className="text-sm text-neutral-600">
                      Geben Sie die Paletten-Nummer direkt ein
                    </p>
                  </div>
                  
                  <div className="space-y-3">
                    <Label htmlFor="manual-code">Paletten-Nummer</Label>
                    <Input
                      id="manual-code"
                      type="text"
                      placeholder="z.B. PAL-001, dfdfd, 37748"
                      value={manualCode}
                      onChange={(e) => setManualCode(e.target.value)}
                      onKeyPress={(e) => {
                        if (e.key === "Enter") {
                          handleManualSearch();
                        }
                      }}
                    />
                    
                    <div className="flex gap-3">
                      <Button 
                        onClick={handleManualSearch}
                        className="flex-1"
                        disabled={!manualCode.trim()}
                      >
                        <Search className="mr-2 h-4 w-4" />
                        Palette suchen
                      </Button>
                      
                      <Button 
                        onClick={handleBackToDashboard}
                        variant="outline"
                      >
                        Zurück zum Dashboard
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}