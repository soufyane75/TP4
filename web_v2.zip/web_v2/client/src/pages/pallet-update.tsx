import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { updatePalletSchema, type UpdatePallet, type Pallet } from "@shared/schema";
import { useAuth } from "@/hooks/use-auth";
import { Card, CardContent } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";
import { Package, LogOut } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";

interface PalletUpdateProps {
  palletCode: string;
}

export default function PalletUpdate({ palletCode }: PalletUpdateProps) {
  const { user, logout } = useAuth();
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();

  const { data: pallet, isLoading, error } = useQuery<Pallet>({
    queryKey: [`/api/pallets/code/${palletCode}`],
    retry: false,
  });

  const form = useForm<UpdatePallet>({
    resolver: zodResolver(updatePalletSchema),
    defaultValues: {
      cartonCount: undefined,
      itemsPerCarton: undefined,
    },
  });

  const { watch } = form;
  const cartonCount = watch("cartonCount");
  const itemsPerCarton = watch("itemsPerCarton");
  const totalItems = cartonCount && itemsPerCarton ? cartonCount * itemsPerCarton : 0;

  useEffect(() => {
    if (pallet) {
      form.reset({
        cartonCount: pallet.cartonCount || undefined,
        itemsPerCarton: pallet.itemsPerCarton || undefined,
      });
    }
  }, [pallet, form]);

  const updateMutation = useMutation({
    mutationFn: async (data: UpdatePallet) => {
      const response = await apiRequest("PATCH", `/api/pallets/${pallet?.id}`, data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/pallets/code/${palletCode}`] });
      toast({
        title: "Palette erfolgreich aktualisiert",
        description: "Die Änderungen wurden gespeichert",
      });
      setLocation("/dashboard");
    },
    onError: (error: any) => {
      toast({
        title: "Fehler beim Aktualisieren",
        description: error.message || "Unbekannter Fehler",
        variant: "destructive",
      });
    },
  });

  const handleLogout = async () => {
    try {
      await logout();
    } catch (error) {
      toast({
        title: "Fehler beim Abmelden",
        description: "Bitte versuchen Sie es erneut",
        variant: "destructive",
      });
    }
  };

  const onSubmit = async (data: UpdatePallet) => {
    await updateMutation.mutateAsync(data);
  };

  const handleCancel = () => {
    setLocation("/dashboard");
  };

  const getStatusBadge = (status: string) => {
    if (status === "abgeschlossen") {
      return <span className="px-2 py-1 text-xs rounded-full bg-success text-white">Abgeschlossen</span>;
    }
    return <span className="px-2 py-1 text-xs rounded-full bg-warning text-white">Offen</span>;
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-neutral-600">Palette wird geladen...</p>
        </div>
      </div>
    );
  }

  if (error || !pallet) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="w-full max-w-md mx-4">
          <CardContent className="pt-6">
            <div className="text-center">
              <Package className="h-8 w-8 text-red-500 mx-auto mb-4" />
              <h1 className="text-2xl font-bold text-gray-900 mb-2">Palette nicht gefunden</h1>
              <p className="text-sm text-gray-600 mb-4">
                Die angeforderte Palette konnte nicht gefunden werden.
              </p>
              <Button onClick={() => setLocation("/dashboard")}>
                Zurück zum Dashboard
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-neutral-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-neutral-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <Package className="text-primary text-2xl" />
              <h1 className="text-xl font-semibold text-neutral-900">Paletten Management</h1>
            </div>
            <div className="flex items-center space-x-4">
              <span className="text-sm text-neutral-600">{user?.name}</span>
              <span className="px-3 py-1 bg-primary text-white text-xs rounded-full font-medium">
                {user?.role === "admin" ? "Admin" : "Mitarbeiter"}
              </span>
              <Button
                variant="ghost"
                size="sm"
                onClick={handleLogout}
                className="text-neutral-600 hover:text-neutral-900"
              >
                <LogOut className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Card>
          <CardContent className="p-8">
            <div className="text-center mb-8">
              <Package className="mx-auto h-12 w-12 text-primary mb-4" />
              <h2 className="text-2xl font-semibold text-neutral-900">Palette bearbeiten</h2>
              <p className="text-neutral-600 mt-2">
                ID: <span className="font-mono">{pallet.palletCode}</span>
              </p>
            </div>

            {/* Pallet Info */}
            <div className="bg-neutral-50 rounded-lg p-6 mb-8">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                <div>
                  <span className="text-neutral-600">Typ:</span>
                  <span className="ml-2 font-medium">{pallet.type}</span>
                </div>
                <div>
                  <span className="text-neutral-600">Produktionsdatum:</span>
                  <span className="ml-2 font-medium">{pallet.productionDate}</span>
                </div>
                <div>
                  <span className="text-neutral-600">MHD:</span>
                  <span className="ml-2 font-medium">{pallet.expiryDate}</span>
                </div>
                <div>
                  <span className="text-neutral-600">Status:</span>
                  <span className="ml-2">{getStatusBadge(pallet.status)}</span>
                </div>
              </div>
            </div>

            {/* Update Form */}
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <FormField
                  control={form.control}
                  name="cartonCount"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Anzahl Kartons auf der Palette</FormLabel>
                      <FormControl>
                        <Input
                          {...field}
                          type="number"
                          min="1"
                          placeholder="z.B. 24"
                          className="text-lg py-4"
                          disabled={updateMutation.isPending}
                          onChange={(e) => field.onChange(e.target.value ? parseInt(e.target.value) : undefined)}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="itemsPerCarton"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Anzahl Stücke pro Karton</FormLabel>
                      <FormControl>
                        <Input
                          {...field}
                          type="number"
                          min="1"
                          placeholder="z.B. 12"
                          className="text-lg py-4"
                          disabled={updateMutation.isPending}
                          onChange={(e) => field.onChange(e.target.value ? parseInt(e.target.value) : undefined)}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {/* Total Calculation */}
                <div className="bg-neutral-50 rounded-lg p-4">
                  <div className="flex justify-between items-center">
                    <span className="text-neutral-700 font-medium">Gesamtstückzahl:</span>
                    <span className="text-2xl font-semibold text-primary">{totalItems}</span>
                  </div>
                </div>

                <div className="flex flex-col sm:flex-row gap-4 pt-4">
                  <Button
                    type="submit"
                    className="flex-1 text-lg min-h-[48px]"
                    disabled={updateMutation.isPending}
                  >
                    {updateMutation.isPending ? "Speichern..." : "Speichern"}
                  </Button>

                  <Button
                    type="button"
                    variant="secondary"
                    onClick={handleCancel}
                    className="flex-1 text-lg min-h-[48px]"
                    disabled={updateMutation.isPending}
                  >
                    Abbrechen
                  </Button>
                </div>
              </form>
            </Form>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
