import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Sidebar } from "@/components/sidebar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { AlertTriangle, Calendar, Package, MapPin, Trash2 } from "lucide-react";
import { formatDate } from "@/lib/utils";
import type { Pallet } from "@shared/schema";

export default function ExpiryAlertsPage() {
  const [selectedFilter, setSelectedFilter] = useState<"all" | "critical" | "warning">("all");

  const { data: expiringPallets = [], isLoading, error } = useQuery<Pallet[]>({
    queryKey: ["/api/pallets/expiry-alerts"],
  });

  const getExpiryStatus = (expiryDate: string) => {
    const today = new Date();
    const expiry = new Date(expiryDate);
    const diffTime = expiry.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

    if (diffDays < 0) {
      return { status: "expired", label: "Abgelaufen", variant: "destructive" as const, days: Math.abs(diffDays) };
    } else if (diffDays <= 30) {
      return { status: "critical", label: "Kritisch", variant: "destructive" as const, days: diffDays };
    } else if (diffDays <= 90) {
      return { status: "warning", label: "Warnung", variant: "secondary" as const, days: diffDays };
    } else {
      return { status: "normal", label: "Normal", variant: "default" as const, days: diffDays };
    }
  };

  const filteredPallets = expiringPallets.filter(pallet => {
    const { status } = getExpiryStatus(pallet.expiryDate);
    if (selectedFilter === "critical") return status === "critical" || status === "expired";
    if (selectedFilter === "warning") return status === "warning";
    return true;
  });

  const criticalCount = expiringPallets.filter(p => {
    const { status } = getExpiryStatus(p.expiryDate);
    return status === "critical" || status === "expired";
  }).length;

  const warningCount = expiringPallets.filter(p => {
    const { status } = getExpiryStatus(p.expiryDate);
    return status === "warning";
  }).length;

  if (isLoading) {
    return (
      <div className="flex h-screen bg-neutral-50">
        <Sidebar />
        <main className="flex-1 overflow-auto">
          <div className="max-w-7xl mx-auto p-6">
            <div className="animate-pulse space-y-4">
              <div className="h-8 bg-neutral-200 rounded w-1/4"></div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {[1, 2, 3].map(i => (
                  <div key={i} className="h-32 bg-neutral-200 rounded"></div>
                ))}
              </div>
            </div>
          </div>
        </main>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex h-screen bg-neutral-50">
        <Sidebar />
        <main className="flex-1 overflow-auto">
          <div className="max-w-7xl mx-auto p-6">
            <Alert variant="destructive">
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription>
                Fehler beim Laden der MHD-Warnungen. Bitte versuchen Sie es erneut.
              </AlertDescription>
            </Alert>
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-neutral-50">
      <Sidebar />
      
      <main className="flex-1 overflow-auto">
        <div className="max-w-7xl mx-auto p-6">
          {/* Header */}
          <div className="mb-8">
            <div className="flex items-center gap-3 mb-4">
              <div className="p-2 bg-orange-100 rounded-lg">
                <AlertTriangle className="h-6 w-6 text-orange-600" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-neutral-900">MHD-Alarme</h1>
                <p className="text-neutral-600">Überwachung ablaufender Produkte</p>
              </div>
            </div>

            {/* Summary Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-neutral-600">Kritische Warnungen</p>
                      <p className="text-2xl font-bold text-red-600">{criticalCount}</p>
                    </div>
                    <div className="p-2 bg-red-100 rounded-lg">
                      <AlertTriangle className="h-5 w-5 text-red-600" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-neutral-600">Allgemeine Warnungen</p>
                      <p className="text-2xl font-bold text-orange-600">{warningCount}</p>
                    </div>
                    <div className="p-2 bg-orange-100 rounded-lg">
                      <Calendar className="h-5 w-5 text-orange-600" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-neutral-600">Überwachte Paletten</p>
                      <p className="text-2xl font-bold text-neutral-900">{expiringPallets.length}</p>
                    </div>
                    <div className="p-2 bg-neutral-100 rounded-lg">
                      <Package className="h-5 w-5 text-neutral-600" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Filter Buttons */}
            <div className="flex gap-2">
              <Button
                variant={selectedFilter === "all" ? "default" : "outline"}
                onClick={() => setSelectedFilter("all")}
                size="sm"
              >
                Alle ({expiringPallets.length})
              </Button>
              <Button
                variant={selectedFilter === "critical" ? "default" : "outline"}
                onClick={() => setSelectedFilter("critical")}
                size="sm"
              >
                Kritisch ({criticalCount})
              </Button>
              <Button
                variant={selectedFilter === "warning" ? "default" : "outline"}
                onClick={() => setSelectedFilter("warning")}
                size="sm"
              >
                Warnung ({warningCount})
              </Button>
            </div>
          </div>

          {/* Pallets List */}
          {filteredPallets.length === 0 ? (
            <Card>
              <CardContent className="p-8 text-center">
                <Package className="mx-auto h-12 w-12 text-neutral-400 mb-4" />
                <h3 className="text-lg font-medium text-neutral-900 mb-2">
                  {selectedFilter === "all" 
                    ? "Keine ablaufenden Paletten gefunden" 
                    : `Keine ${selectedFilter === "critical" ? "kritischen" : "Warn-"}meldungen`
                  }
                </h3>
                <p className="text-neutral-600">
                  {selectedFilter === "all" 
                    ? "Alle Paletten haben ausreichend lange MHD." 
                    : "Filtern Sie nach anderen Kategorien oder prüfen Sie alle Einträge."
                  }
                </p>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-4">
              {filteredPallets.map((pallet) => {
                const expiryInfo = getExpiryStatus(pallet.expiryDate);
                
                return (
                  <Card key={pallet.id} className="overflow-hidden">
                    <CardContent className="p-6">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-3 mb-3">
                            <h3 className="text-lg font-semibold text-neutral-900">
                              {pallet.palletNumber}
                            </h3>
                            <Badge variant={expiryInfo.variant}>
                              {expiryInfo.status === "expired" 
                                ? `${expiryInfo.days} Tage überfällig`
                                : `${expiryInfo.days} Tage verbleibend`
                              }
                            </Badge>
                            <Badge variant="outline">
                              {pallet.status === "abgeschlossen" ? "Abgeschlossen" : "Offen"}
                            </Badge>
                          </div>

                          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 text-sm">
                            <div>
                              <p className="text-neutral-600">Artikel-Nr.</p>
                              <p className="font-medium">{pallet.articleNumber || "Nicht angegeben"}</p>
                            </div>
                            <div>
                              <p className="text-neutral-600">Beschreibung</p>
                              <p className="font-medium truncate" title={pallet.productDescription}>
                                {pallet.productDescription || "Keine Beschreibung"}
                              </p>
                            </div>
                            <div>
                              <p className="text-neutral-600">Charge</p>
                              <p className="font-medium">{pallet.chargeNumber || "Nicht angegeben"}</p>
                            </div>
                            <div className="flex items-center gap-1">
                              <MapPin className="h-4 w-4 text-neutral-400" />
                              <div>
                                <p className="text-neutral-600">Standort</p>
                                <p className="font-medium">{pallet.location || "Nicht angegeben"}</p>
                              </div>
                            </div>
                          </div>

                          <div className="mt-4 flex items-center justify-between">
                            <div className="flex items-center gap-4 text-sm text-neutral-600">
                              <span>MHD: {formatDate(pallet.expiryDate)}</span>
                              <span>Artikel: {pallet.totalItems || 0}</span>
                              <span>Erstellt: {formatDate(pallet.createdAt)}</span>
                            </div>
                          </div>
                        </div>

                        <div className="ml-4">
                          {expiryInfo.status === "expired" && (
                            <div className="flex items-center gap-2 text-red-600">
                              <Trash2 className="h-5 w-5" />
                              <span className="text-sm font-medium">Abgelaufen</span>
                            </div>
                          )}
                          {expiryInfo.status === "critical" && (
                            <div className="flex items-center gap-2 text-red-600">
                              <AlertTriangle className="h-5 w-5" />
                              <span className="text-sm font-medium">Kritisch</span>
                            </div>
                          )}
                          {expiryInfo.status === "warning" && (
                            <div className="flex items-center gap-2 text-orange-600">
                              <Calendar className="h-5 w-5" />
                              <span className="text-sm font-medium">Warnung</span>
                            </div>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          )}
        </div>
      </main>
    </div>
  );
}