import { users, pallets, articles, type User, type InsertUser, type Pallet, type InsertPallet, type UpdatePallet, type Article, type InsertArticle, type UpdateArticle, type CreateUser, type UpdateUser } from "@shared/schema";
import { db } from "./db";
import { eq, sql } from "drizzle-orm";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  getAllUsers(): Promise<User[]>;
  createUserAdmin(user: CreateUser): Promise<User>;
  updateUser(id: number, updates: UpdateUser): Promise<User | undefined>;
  deleteUser(id: number): Promise<boolean>;

  // Article methods
  getAllArticles(): Promise<Article[]>;
  getArticle(id: number): Promise<Article | undefined>;
  createArticle(article: InsertArticle): Promise<Article>;
  updateArticle(id: number, updates: UpdateArticle): Promise<Article | undefined>;
  deleteArticle(id: number): Promise<boolean>;

  // Pallet methods
  getPallet(id: number): Promise<Pallet | undefined>;
  getPalletByCode(palletCode: string): Promise<Pallet | undefined>;
  getAllPallets(): Promise<Pallet[]>;
  createPallet(pallet: InsertPallet & { palletCode: string; qrCodeData: string }): Promise<Pallet>;
  updatePallet(id: number, updates: Partial<UpdatePallet & { status?: string; totalItems?: number; qrCodeData?: string }>): Promise<Pallet | undefined>;
  getCompletedPallets(): Promise<Pallet[]>;
  getPalletsExpiringWithinMonths(months: number): Promise<Pallet[]>;
}

export class DatabaseStorage implements IStorage {
  private initPromise: Promise<void>;

  constructor() {
    // Initialize hardcoded users on startup - store promise to await later
    this.initPromise = this.initializeUsers();
  }

  private async initializeUsers() {
    try {
      // Wait a bit for database connection to be ready
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Check if admin user exists
      const adminExists = await this.getUserByUsername("admin");
      if (!adminExists) {
        await this.createUser({
          username: "admin",
          password: "admin123", // In production, this should be hashed
          role: "admin",
          name: "Administrator"
        });
        console.log("Admin user created successfully");
      }

      // Check if employee user exists
      const employeeExists = await this.getUserByUsername("mitarbeiter");
      if (!employeeExists) {
        await this.createUser({
          username: "mitarbeiter",
          password: "mitarbeiter123", // In production, this should be hashed
          role: "mitarbeiter",
          name: "Mitarbeiter"
        });
        console.log("Employee user created successfully");
      }
    } catch (error) {
      console.error("Error initializing users:", error);
      // Don't throw - allow app to continue running
    }
  }

  async ensureInitialized() {
    await this.initPromise;
  }

  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async getAllUsers(): Promise<User[]> {
    const allUsers = await db.select().from(users).orderBy(users.username);
    return allUsers;
  }

  async createUserAdmin(createUser: CreateUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(createUser)
      .returning();
    return user;
  }

  async updateUser(id: number, updates: UpdateUser): Promise<User | undefined> {
    const [user] = await db
      .update(users)
      .set(updates)
      .where(eq(users.id, id))
      .returning();
    return user || undefined;
  }

  async deleteUser(id: number): Promise<boolean> {
    const result = await db
      .delete(users)
      .where(eq(users.id, id));
    return (result.rowCount || 0) > 0;
  }

  async getAllArticles(): Promise<Article[]> {
    const allArticles = await db.select().from(articles).orderBy(articles.createdAt);
    return allArticles.reverse(); // Most recent first
  }

  async getArticle(id: number): Promise<Article | undefined> {
    const [article] = await db.select().from(articles).where(eq(articles.id, id));
    return article || undefined;
  }

  async createArticle(insertArticle: InsertArticle): Promise<Article> {
    const [article] = await db
      .insert(articles)
      .values(insertArticle)
      .returning();
    return article;
  }

  async updateArticle(id: number, updates: UpdateArticle): Promise<Article | undefined> {
    const [article] = await db
      .update(articles)
      .set(updates)
      .where(eq(articles.id, id))
      .returning();
    return article || undefined;
  }

  async deleteArticle(id: number): Promise<boolean> {
    const result = await db
      .delete(articles)
      .where(eq(articles.id, id));
    return (result.rowCount || 0) > 0;
  }

  async getPallet(id: number): Promise<Pallet | undefined> {
    const [pallet] = await db.select().from(pallets).where(eq(pallets.id, id));
    return pallet || undefined;
  }

  async getPalletByCode(palletNumber: string): Promise<Pallet | undefined> {
    const [pallet] = await db.select().from(pallets).where(eq(pallets.palletNumber, palletNumber));
    return pallet || undefined;
  }

  async getAllPallets(): Promise<Pallet[]> {
    const allPallets = await db.select().from(pallets).orderBy(pallets.createdAt);
    return allPallets.reverse(); // Most recent first
  }

  async createPallet(palletData: InsertPallet & { qrCodeData: string }): Promise<Pallet> {
    const totalItems = palletData.cartonCount * palletData.itemsPerCarton;
    
    const [pallet] = await db
      .insert(pallets)
      .values({
        palletNumber: palletData.palletNumber,
        productDescription: palletData.productDescription,
        chargeNumber: palletData.chargeNumber,
        articleNumber: palletData.articleNumber,
        expiryDate: palletData.expiryDate,
        letterCode: palletData.letterCode,
        cartonCount: palletData.cartonCount,
        itemsPerCarton: palletData.itemsPerCarton,
        totalItems: totalItems,
        status: "offen",
        qrCodeData: palletData.qrCodeData,
      })
      .returning();
    return pallet;
  }

  async updatePallet(id: number, updates: Partial<UpdatePallet & { status?: string; totalItems?: number; qrCodeData?: string }>): Promise<Pallet | undefined> {
    // Auto-complete if both cartonCount and itemsPerCarton are provided
    const updateData = { ...updates };
    if (updates.cartonCount && updates.itemsPerCarton) {
      updateData.totalItems = updates.cartonCount * updates.itemsPerCarton;
      updateData.status = "abgeschlossen";
    }

    const [pallet] = await db
      .update(pallets)
      .set(updateData)
      .where(eq(pallets.id, id))
      .returning();
    
    return pallet || undefined;
  }

  async getCompletedPallets(): Promise<Pallet[]> {
    const completedPallets = await db
      .select()
      .from(pallets)
      .where(eq(pallets.status, "abgeschlossen"))
      .orderBy(pallets.createdAt);
    return completedPallets.reverse(); // Most recent first
  }

  async getPalletsExpiringWithinMonths(months: number): Promise<Pallet[]> {
    const targetDate = new Date();
    targetDate.setMonth(targetDate.getMonth() + months);
    const targetDateString = targetDate.toISOString().split('T')[0];
    
    const expiringPallets = await db
      .select()
      .from(pallets)
      .where(sql`${pallets.expiryDate} <= ${targetDateString}`)
      .orderBy(pallets.expiryDate);
    
    return expiringPallets;
  }
}

export const storage = new DatabaseStorage();
