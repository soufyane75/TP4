import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { loginSchema, insertPalletSchema, updatePalletSchema, insertArticleSchema, updateArticleSchema, createUserSchema, updateUserSchema } from "@shared/schema";
import { ZodError } from "zod";
import session from "express-session";
import MemoryStore from "memorystore";
import QRCode from "qrcode";

const MemStore = MemoryStore(session);

declare module "express-session" {
  interface SessionData {
    userId?: number;
    userRole?: string;
  }
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Ensure database is initialized before setting up routes
  try {
    await storage.ensureInitialized();
    console.log("Database initialization completed");
  } catch (error) {
    console.error("Database initialization failed:", error);
  }

  // Session middleware
  app.use(session({
    secret: process.env.SESSION_SECRET || "pallet-management-secret-key",
    resave: false,
    saveUninitialized: false,
    store: new MemStore({
      checkPeriod: 86400000 // Prune expired entries every 24h
    }),
    cookie: {
      secure: false, // Set to true in production with HTTPS
      httpOnly: true,
      maxAge: 24 * 60 * 60 * 1000 // 24 hours
    }
  }));

  // Authentication middleware
  const requireAuth = (req: any, res: any, next: any) => {
    if (!req.session.userId) {
      return res.status(401).json({ message: "Authentifizierung erforderlich" });
    }
    next();
  };

  const requireAdmin = (req: any, res: any, next: any) => {
    if (!req.session.userId || req.session.userRole !== "admin") {
      return res.status(403).json({ message: "Admin-Berechtigung erforderlich" });
    }
    next();
  };

  // Generate unique pallet code
  const generatePalletCode = async (): Promise<string> => {
    const pallets = await storage.getAllPallets();
    const nextNumber = pallets.length + 1;
    return `PAL-${nextNumber.toString().padStart(3, '0')}`;
  };

  // Auth routes
  app.post("/api/auth/login", async (req, res) => {
    try {
      const { username, password } = loginSchema.parse(req.body);
      
      const user = await storage.getUserByUsername(username);
      if (!user || user.password !== password) {
        return res.status(401).json({ message: "Ungültige Anmeldedaten" });
      }

      req.session.userId = user.id;
      req.session.userRole = user.role;
      
      res.json({
        id: user.id,
        username: user.username,
        name: user.name,
        role: user.role
      });
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: "Ungültige Eingabedaten", errors: error.errors });
      }
      res.status(500).json({ message: "Interner Serverfehler" });
    }
  });

  app.post("/api/auth/logout", (req, res) => {
    req.session.destroy((err) => {
      if (err) {
        return res.status(500).json({ message: "Fehler beim Abmelden" });
      }
      res.json({ message: "Erfolgreich abgemeldet" });
    });
  });

  app.get("/api/auth/me", requireAuth, async (req, res) => {
    try {
      const user = await storage.getUser(req.session.userId!);
      if (!user) {
        return res.status(404).json({ message: "Benutzer nicht gefunden" });
      }
      
      res.json({
        id: user.id,
        username: user.username,
        name: user.name,
        role: user.role
      });
    } catch (error) {
      res.status(500).json({ message: "Interner Serverfehler" });
    }
  });

  // Pallet routes
  app.get("/api/pallets", requireAuth, async (req, res) => {
    try {
      const pallets = await storage.getAllPallets();
      res.json(pallets);
    } catch (error) {
      res.status(500).json({ message: "Fehler beim Laden der Paletten" });
    }
  });

  app.get("/api/pallets/completed", requireAuth, async (req, res) => {
    try {
      const pallets = await storage.getCompletedPallets();
      res.json(pallets);
    } catch (error) {
      res.status(500).json({ message: "Fehler beim Laden der abgeschlossenen Paletten" });
    }
  });

  app.get("/api/pallets/expiry-alerts", requireAuth, async (req, res) => {
    try {
      const pallets = await storage.getPalletsExpiringWithinMonths(3);
      res.json(pallets);
    } catch (error) {
      res.status(500).json({ message: "Fehler beim Laden der MHD-Warnungen" });
    }
  });

  app.get("/api/pallets/:id", requireAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const pallet = await storage.getPallet(id);
      
      if (!pallet) {
        return res.status(404).json({ message: "Palette nicht gefunden" });
      }
      
      res.json(pallet);
    } catch (error) {
      res.status(500).json({ message: "Fehler beim Laden der Palette" });
    }
  });

  app.get("/api/pallets/code/:code", requireAuth, async (req, res) => {
    try {
      const pallet = await storage.getPalletByCode(req.params.code);
      
      if (!pallet) {
        return res.status(404).json({ message: "Palette nicht gefunden" });
      }
      
      res.json(pallet);
    } catch (error) {
      res.status(500).json({ message: "Fehler beim Laden der Palette" });
    }
  });

  app.post("/api/pallets", requireAdmin, async (req, res) => {
    try {
      const palletData = insertPalletSchema.parse(req.body);
      
      // Generate comprehensive QR code data with pallet information
      const qrData = {
        type: "pallet",
        palletNumber: palletData.palletNumber,
        articleNumber: palletData.articleNumber,
        productDescription: palletData.productDescription,
        chargeNumber: palletData.chargeNumber,
        location: palletData.location,
        cartonCount: palletData.cartonCount,
        itemsPerCarton: palletData.itemsPerCarton,
        totalItems: palletData.cartonCount * palletData.itemsPerCarton,
        expiryDate: palletData.expiryDate,
        letterCode: palletData.letterCode,
        updateUrl: `${req.protocol}://${req.get('host')}/pallet/${palletData.palletNumber}`,
        createdAt: new Date().toISOString()
      };
      
      const qrCodeData = await QRCode.toDataURL(JSON.stringify(qrData), {
        width: 256,
        margin: 2,
        color: {
          dark: '#000000',
          light: '#FFFFFF'
        }
      });
      
      const pallet = await storage.createPallet({
        ...palletData,
        qrCodeData
      });
      
      res.status(201).json(pallet);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: "Ungültige Eingabedaten", errors: error.errors });
      }
      res.status(500).json({ message: "Fehler beim Erstellen der Palette" });
    }
  });

  app.patch("/api/pallets/:id", requireAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updates = updatePalletSchema.parse(req.body);
      
      const pallet = await storage.updatePallet(id, updates);
      
      if (!pallet) {
        return res.status(404).json({ message: "Palette nicht gefunden" });
      }
      
      res.json(pallet);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: "Ungültige Eingabedaten", errors: error.errors });
      }
      res.status(500).json({ message: "Fehler beim Aktualisieren der Palette" });
    }
  });

  app.post("/api/pallets/:id/regenerate-qr", requireAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const existingPallet = await storage.getPallet(id);
      
      if (!existingPallet) {
        return res.status(404).json({ message: "Palette nicht gefunden" });
      }

      // Generate new comprehensive QR code data
      const qrData = {
        type: "pallet",
        palletNumber: existingPallet.palletNumber,
        articleNumber: existingPallet.articleNumber,
        productDescription: existingPallet.productDescription,
        chargeNumber: existingPallet.chargeNumber,
        location: existingPallet.location,
        cartonCount: existingPallet.cartonCount,
        itemsPerCarton: existingPallet.itemsPerCarton,
        totalItems: existingPallet.totalItems,
        expiryDate: existingPallet.expiryDate,
        letterCode: existingPallet.letterCode,
        status: existingPallet.status,
        updateUrl: `${req.protocol}://${req.get('host')}/pallet/${existingPallet.palletNumber}`,
        createdAt: existingPallet.createdAt.toISOString(),
        updatedAt: new Date().toISOString()
      };
      
      const qrCodeData = await QRCode.toDataURL(JSON.stringify(qrData), {
        width: 256,
        margin: 2,
        color: {
          dark: '#000000',
          light: '#FFFFFF'
        }
      });

      const updatedPallet = await storage.updatePallet(id, { qrCodeData });
      
      res.json(updatedPallet);
    } catch (error) {
      res.status(500).json({ message: "Fehler beim Regenerieren des QR-Codes" });
    }
  });

  // Article routes
  app.get("/api/articles", requireAdmin, async (req, res) => {
    try {
      const articles = await storage.getAllArticles();
      res.json(articles);
    } catch (error) {
      res.status(500).json({ message: "Fehler beim Laden der Artikel" });
    }
  });

  app.post("/api/articles", requireAdmin, async (req, res) => {
    try {
      const articleData = insertArticleSchema.parse(req.body);
      const article = await storage.createArticle(articleData);
      res.status(201).json(article);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: "Ungültige Eingabedaten", errors: error.errors });
      }
      res.status(500).json({ message: "Fehler beim Erstellen des Artikels" });
    }
  });

  app.patch("/api/articles/:id", requireAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updates = updateArticleSchema.parse(req.body);
      
      const article = await storage.updateArticle(id, updates);
      if (!article) {
        return res.status(404).json({ message: "Artikel nicht gefunden" });
      }
      
      res.json(article);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: "Ungültige Eingabedaten", errors: error.errors });
      }
      res.status(500).json({ message: "Fehler beim Aktualisieren des Artikels" });
    }
  });

  app.delete("/api/articles/:id", requireAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      
      const success = await storage.deleteArticle(id);
      if (!success) {
        return res.status(404).json({ message: "Artikel nicht gefunden" });
      }
      
      res.json({ message: "Artikel erfolgreich gelöscht" });
    } catch (error) {
      res.status(500).json({ message: "Fehler beim Löschen des Artikels" });
    }
  });

  // User management routes (admin only)
  app.get("/api/users", requireAdmin, async (req, res) => {
    try {
      const users = await storage.getAllUsers();
      // Don't send passwords in response
      const usersWithoutPasswords = users.map(({ password, ...user }) => user);
      res.json(usersWithoutPasswords);
    } catch (error) {
      res.status(500).json({ message: "Fehler beim Laden der Benutzer" });
    }
  });

  app.post("/api/users", requireAdmin, async (req, res) => {
    try {
      const userData = createUserSchema.parse(req.body);
      
      // Check if username already exists
      const existingUser = await storage.getUserByUsername(userData.username);
      if (existingUser) {
        return res.status(400).json({ message: "Benutzername bereits vergeben" });
      }
      
      const user = await storage.createUserAdmin(userData);
      const { password, ...userWithoutPassword } = user;
      res.status(201).json(userWithoutPassword);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: "Ungültige Eingabedaten", errors: error.errors });
      }
      res.status(500).json({ message: "Fehler beim Erstellen des Benutzers" });
    }
  });

  app.patch("/api/users/:id", requireAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updates = updateUserSchema.parse(req.body);
      
      const user = await storage.updateUser(id, updates);
      if (!user) {
        return res.status(404).json({ message: "Benutzer nicht gefunden" });
      }
      
      const { password, ...userWithoutPassword } = user;
      res.json(userWithoutPassword);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: "Ungültige Eingabedaten", errors: error.errors });
      }
      res.status(500).json({ message: "Fehler beim Aktualisieren des Benutzers" });
    }
  });

  app.delete("/api/users/:id", requireAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      
      // Prevent deleting current user
      if (id === req.session.userId) {
        return res.status(400).json({ message: "Sie können sich nicht selbst löschen" });
      }
      
      const success = await storage.deleteUser(id);
      if (!success) {
        return res.status(404).json({ message: "Benutzer nicht gefunden" });
      }
      
      res.json({ message: "Benutzer erfolgreich gelöscht" });
    } catch (error) {
      res.status(500).json({ message: "Fehler beim Löschen des Benutzers" });
    }
  });

  // Stats route for admin dashboard
  app.get("/api/stats", requireAdmin, async (req, res) => {
    try {
      const allPallets = await storage.getAllPallets();
      const today = new Date().toISOString().split('T')[0];
      
      const stats = {
        openPallets: allPallets.filter(p => p.status === "offen").length,
        completedPallets: allPallets.filter(p => p.status === "abgeschlossen").length,
        todayCreated: allPallets.filter(p => 
          p.createdAt.toISOString().split('T')[0] === today
        ).length
      };
      
      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: "Fehler beim Laden der Statistiken" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
