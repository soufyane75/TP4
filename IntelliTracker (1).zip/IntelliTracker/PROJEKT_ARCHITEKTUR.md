# Paletten Management System - Projektarchitektur

## Projektübersicht
Ein vollständiges rollenbasiertes Palettenverwaltungssystem für die Lebensmittelproduktion mit QR-Code-Workflow und moderner Benutzeroberfläche.

---

## 🏗️ Technische Architektur

### Frontend (React/TypeScript)
- **Framework**: React 18 mit TypeScript
- **Build Tool**: Vite für optimierte Entwicklung
- **Styling**: Tailwind CSS + Shadcn/UI Komponenten
- **State Management**: TanStack Query für Server-State
- **Routing**: Wouter (leichtgewichtige Alternative zu React Router)
- **Forms**: React Hook Form mit Zod-Validierung
- **PDF Export**: jsPDF + jsPDF-AutoTable

### Backend (Node.js/Express)
- **Runtime**: Node.js mit TypeScript
- **Framework**: Express.js
- **ORM**: Drizzle ORM für typsichere Datenbankoperationen
- **Session Management**: Express-Session mit MemoryStore
- **Validierung**: Zod Schemas für Request/Response Validierung
- **QR-Code**: QRCode Library für QR-Code Generierung

### Datenbank (PostgreSQL)
- **System**: PostgreSQL (über Neon Serverless)
- **Schema Management**: Drizzle ORM
- **Tabellen**: Users, Articles, Pallets
- **Beziehungen**: Referentielle Integrität mit Foreign Keys

---

## 📊 Datenbankschema

### Users Tabelle
```sql
- id (Serial, Primary Key)
- username (Text, Unique)
- password (Text, Hashed)
- name (Text)
- role (Text: 'admin' | 'mitarbeiter')
- created_at (Timestamp)
```

### Articles Tabelle
```sql
- id (Serial, Primary Key)
- article_number (Text, Unique)
- name (Text)
- description (Text, Optional)
- default_items_per_carton (Integer)
- created_at (Timestamp)
```

### Pallets Tabelle
```sql
- id (Serial, Primary Key)
- pallet_number (Text, Unique)
- product_description (Text)
- charge_number (Text)
- article_number (Text)
- expiry_date (Text)
- letter_code (Text: 'A'|'S'|'M'|'G')
- carton_count (Integer)
- items_per_carton (Integer)
- total_items (Integer, Calculated)
- status (Text: 'offen'|'abgeschlossen')
- location (Text: 'kühlhaus'|'tiefkühler'|'versandt')
- qr_code_data (Text)
- created_at (Timestamp)
```

---

## 🔐 Sicherheitskonzept

### Authentifizierung
- **Session-basiert**: Sichere Server-Side Sessions
- **Password Hashing**: Bcrypt für sichere Passwort-Speicherung
- **Session Timeout**: 24 Stunden automatischer Logout
- **CSRF Protection**: HTTPOnly Cookies

### Autorisierung
- **Rollenbasiert**: Admin und Mitarbeiter Rollen
- **Route Protection**: Middleware für geschützte Endpunkte
- **Granulare Berechtigungen**:
  - Admins: Vollzugriff auf alle Funktionen
  - Mitarbeiter: Palette bearbeiten, QR-Scanner nutzen

### API Sicherheit
- **Input Validierung**: Zod Schemas für alle Eingaben
- **SQL Injection Schutz**: Drizzle ORM mit Prepared Statements
- **Error Handling**: Strukturiertes Error Management
- **Rate Limiting**: Session-basierte Zugriffskontrolle

---

## 🌐 API Endpoints

### Authentifizierung
```
POST   /api/auth/login     - Benutzer anmelden
POST   /api/auth/logout    - Benutzer abmelden
GET    /api/auth/me        - Aktuelle Session prüfen
```

### Paletten
```
GET    /api/pallets            - Alle Paletten abrufen
POST   /api/pallets            - Neue Palette erstellen (Admin)
GET    /api/pallets/:id        - Palette nach ID
GET    /api/pallets/code/:code - Palette nach Code
PATCH  /api/pallets/:id        - Palette aktualisieren
GET    /api/pallets/completed  - Abgeschlossene Paletten
```

### Artikel
```
GET    /api/articles     - Alle Artikel abrufen (Admin)
POST   /api/articles     - Artikel erstellen (Admin)
PATCH  /api/articles/:id - Artikel aktualisieren (Admin)
DELETE /api/articles/:id - Artikel löschen (Admin)
```

### Benutzer
```
GET    /api/users        - Alle Benutzer (Admin)
POST   /api/users        - Benutzer erstellen (Admin)
PATCH  /api/users/:id    - Benutzer aktualisieren (Admin)
DELETE /api/users/:id    - Benutzer löschen (Admin)
```

### Statistiken
```
GET    /api/stats        - Dashboard Statistiken
```

---

## 🎯 Funktionale Komponenten

### Admin Dashboard
- **Übersicht**: Statistiken zu offenen/abgeschlossenen Paletten
- **Palettenverwaltung**: Vollständige CRUD-Operationen
- **Artikelverwaltung**: Produktkatalog verwalten
- **Benutzerverwaltung**: Mitarbeiter-Accounts verwalten
- **Export-System**: PDF-Export mit Filteroptionen

### Mitarbeiter Dashboard
- **Offene Paletten**: Liste aller zu bearbeitenden Paletten
- **QR-Scanner**: Kamera-basierte QR-Code-Erkennung
- **Palette bearbeiten**: Kartonanzahl und Stückzahl eingeben
- **Status-Updates**: Automatisches Abschließen bei Vollständigkeit

### QR-Code System
- **Generierung**: Automatische QR-Code-Erstellung bei Palette-Erstellung
- **Scanner**: Kamera-Zugriff für Mobile/Tablet Geräte
- **Deep Linking**: Direkte Navigation zur Palette-Bearbeitung

### Export System
- **PDF-Generierung**: Professionelle PDF-Berichte
- **Zeitfilter**: Heute, Gestern, Letzte 7/30 Tage, Monatsfilter
- **Batch-Export**: Mehrere Paletten gleichzeitig
- **Einzelexport**: Individuelle Palette-Berichte

---

## 📱 Benutzeroberfläche

### Design System
- **UI Library**: Shadcn/UI für konsistente Komponenten
- **Responsive**: Optimiert für Tablet-Nutzung
- **Dark Mode**: Unterstützung geplant
- **Accessibility**: WCAG-konforme Implementierung

### Navigation
- **Sidebar**: Rollenbasierte Navigation
- **Breadcrumbs**: Klare Seitenstruktur
- **Mobile**: Kollapsible Sidebar für kleinere Bildschirme

### Formulare
- **Validierung**: Echtzeit-Validierung mit Zod
- **Auto-Fill**: Artikel-basierte Vorausfüllung
- **Error Handling**: Benutzerfreundliche Fehlermeldungen

---

## 🚀 Deployment & Performance

### Hosting
- **Platform**: Replit (Development/Demo)
- **Database**: Neon Serverless PostgreSQL
- **File Storage**: Lokale PDF-Generierung

### Performance
- **Bundle Optimization**: Vite für optimale Build-Größe
- **Lazy Loading**: Code-Splitting für bessere Ladezeiten
- **Caching**: TanStack Query für intelligentes Caching
- **Database**: Indizierte Abfragen für schnelle Suche

### Monitoring
- **Error Tracking**: Strukturiertes Logging
- **Performance**: Ladezeit-Optimierung
- **Session Management**: Sichere Session-Verwaltung

---

## 🔄 Workflow

### Palette-Lebenszyklus
1. **Erstellung** (Admin): Palette mit QR-Code generieren
2. **Bearbeitung** (Mitarbeiter): QR-Code scannen oder manuell suchen
3. **Vervollständigung**: Kartonanzahl und Stückzahl eingeben
4. **Abschluss**: Automatischer Status-Wechsel zu "abgeschlossen"
5. **Standort**: Location-Tracking (Kühlhaus/Tiefkühler/Versandt)
6. **Export**: PDF-Berichte für Dokumentation

### Datenfluss
1. Frontend → API Request
2. Middleware → Authentifizierung/Autorisierung
3. Controller → Input Validierung (Zod)
4. Service Layer → Business Logic
5. Database → Drizzle ORM
6. Response → JSON/PDF

---

## 📈 Erweiterungsmöglichkeiten

### Geplante Features
- **Barcode Support**: Zusätzlich zu QR-Codes
- **Mobile App**: Native App für Warehouse-Mitarbeiter
- **Analytics**: Detaillierte Produktions-Auswertungen
- **Integration**: ERP-System Anbindung
- **Notifications**: Push-Benachrichtigungen
- **Offline Support**: Offline-Modus für kritische Bereiche

### Skalierung
- **Microservices**: Aufspaltung in spezialisierte Services
- **Redis Caching**: Session und Data Caching
- **Load Balancing**: Horizontale Skalierung
- **Container**: Docker für Production Deployment

---

## 🛠️ Entwicklung

### Code Qualität
- **TypeScript**: Vollständige Typsicherheit
- **ESLint/Prettier**: Code-Formatierung und Standards
- **Git Workflow**: Feature-Branches mit Code Reviews

### Testing (geplant)
- **Unit Tests**: Jest für Business Logic
- **Integration Tests**: API-Endpunkt Tests
- **E2E Tests**: Playwright für UI-Tests

### Dokumentation
- **API Docs**: OpenAPI/Swagger Spezifikation
- **Code Comments**: Inline-Dokumentation
- **README**: Setup und Deployment Anleitungen

---

*Diese Architektur gewährleistet ein skalierbares, sicheres und benutzerfreundliches System für die moderne Palettenverwaltung in der Lebensmittelproduktion.*