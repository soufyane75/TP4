import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { Download, QrCode, Printer, Copy, RefreshCw } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import type { Pallet } from "@shared/schema";

interface QRCodeModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  pallet: Pallet | null;
}

export function QRCodeModal({ open, onOpenChange, pallet }: QRCodeModalProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const regenerateQRMutation = useMutation({
    mutationFn: async (palletId: number) => {
      const response = await fetch(`/api/pallets/${palletId}/regenerate-qr`, {
        method: "POST",
        headers: {
          'Content-Type': 'application/json',
        },
      });
      if (!response.ok) {
        throw new Error('Failed to regenerate QR code');
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/pallets"] });
      toast({
        title: "QR-Code aktualisiert",
        description: "Der QR-Code wurde mit aktuellen Palettendaten regeneriert",
      });
    },
    onError: () => {
      toast({
        title: "Regenerierung fehlgeschlagen",
        description: "Fehler beim Aktualisieren des QR-Codes",
        variant: "destructive",
      });
    },
  });

  const handleDownload = () => {
    if (!pallet) return;

    try {
      // Create a link element and trigger download
      const link = document.createElement("a");
      link.href = pallet.qrCodeData;
      link.download = `QR-Code-${pallet.palletNumber}.png`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);

      toast({
        title: "QR-Code heruntergeladen",
        description: `QR-Code für ${pallet.palletNumber} wurde heruntergeladen`,
      });
    } catch (error) {
      toast({
        title: "Download fehlgeschlagen",
        description: "Fehler beim Herunterladen des QR-Codes",
        variant: "destructive",
      });
    }
  };

  const handlePrint = () => {
    if (!pallet) return;

    try {
      const printWindow = window.open('', '_blank');
      if (!printWindow) {
        toast({
          title: "Druck fehlgeschlagen",
          description: "Pop-up wurde blockiert. Bitte erlauben Sie Pop-ups für diese Seite.",
          variant: "destructive",
        });
        return;
      }

      const printContent = `
        <!DOCTYPE html>
        <html>
        <head>
          <title>QR-Code - ${pallet.palletNumber}</title>
          <style>
            body { 
              font-family: Arial, sans-serif; 
              margin: 20px; 
              text-align: center;
            }
            .qr-container { 
              border: 2px solid #000; 
              padding: 20px; 
              margin: 20px auto; 
              width: 400px;
              background: white;
            }
            .qr-image { 
              width: 200px; 
              height: 200px; 
              margin: 10px auto;
            }
            .pallet-info { 
              margin: 15px 0; 
              font-size: 14px;
              text-align: left;
            }
            .pallet-number { 
              font-size: 24px; 
              font-weight: bold; 
              margin: 10px 0;
            }
            .status-badge {
              display: inline-block;
              padding: 4px 8px;
              border-radius: 4px;
              font-size: 12px;
              font-weight: bold;
              margin: 5px 0;
            }
            .status-open { background: #fef3c7; color: #92400e; }
            .status-completed { background: #d1fae5; color: #065f46; }
            @media print {
              body { margin: 0; }
              .qr-container { border: 1px solid #000; }
            }
          </style>
        </head>
        <body>
          <div class="qr-container">
            <h2>Palette QR-Code</h2>
            <div class="pallet-number">${pallet.palletNumber}</div>
            <img src="${pallet.qrCodeData}" alt="QR Code" class="qr-image" />
            <div class="pallet-info">
              <div><strong>Artikel:</strong> ${pallet.articleNumber || 'Nicht angegeben'}</div>
              <div><strong>Beschreibung:</strong> ${pallet.productDescription || 'Keine Beschreibung'}</div>
              <div><strong>Standort:</strong> ${pallet.location || 'Nicht angegeben'}</div>
              <div><strong>Anzahl Artikel:</strong> ${pallet.totalItems || 0}</div>
              <div><strong>Status:</strong> 
                <span class="status-badge ${pallet.status === 'abgeschlossen' ? 'status-completed' : 'status-open'}">
                  ${pallet.status === 'abgeschlossen' ? 'Abgeschlossen' : 'Offen'}
                </span>
              </div>
              <div><strong>Erstellt:</strong> ${new Date(pallet.createdAt).toLocaleDateString('de-DE')}</div>
            </div>
          </div>
        </body>
        </html>
      `;

      printWindow.document.write(printContent);
      printWindow.document.close();
      printWindow.focus();
      
      setTimeout(() => {
        printWindow.print();
        printWindow.close();
      }, 250);

      toast({
        title: "Druckvorschau geöffnet",
        description: "QR-Code wird gedruckt",
      });
    } catch (error) {
      toast({
        title: "Druck fehlgeschlagen",
        description: "Fehler beim Drucken des QR-Codes",
        variant: "destructive",
      });
    }
  };

  const handleCopyCode = async () => {
    if (!pallet) return;

    try {
      await navigator.clipboard.writeText(pallet.palletNumber);
      toast({
        title: "Kopiert",
        description: "Paletten-Code wurde in die Zwischenablage kopiert",
      });
    } catch (error) {
      toast({
        title: "Kopieren fehlgeschlagen",
        description: "Fehler beim Kopieren des Paletten-Codes",
        variant: "destructive",
      });
    }
  };

  if (!pallet) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md w-full max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>QR-Code</DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Pallet Header Info */}
          <div className="text-center">
            <h3 className="text-lg font-semibold">{pallet.palletNumber}</h3>
            <Badge variant={pallet.status === 'abgeschlossen' ? 'default' : 'secondary'} className="mt-2">
              {pallet.status === 'abgeschlossen' ? 'Abgeschlossen' : 'Offen'}
            </Badge>
          </div>

          {/* QR Code Display */}
          <div className="flex justify-center">
            {pallet.qrCodeData ? (
              <img
                src={pallet.qrCodeData}
                alt={`QR Code für ${pallet.palletNumber}`}
                className="w-48 h-48 border border-neutral-200 rounded-lg"
              />
            ) : (
              <div className="w-48 h-48 bg-neutral-100 border-2 border-dashed border-neutral-300 rounded-lg flex items-center justify-center">
                <div className="text-center">
                  <QrCode className="mx-auto h-12 w-12 text-neutral-400 mb-2" />
                  <p className="text-xs text-neutral-500">
                    QR-Code wird
                    <br />
                    generiert
                  </p>
                </div>
              </div>
            )}
          </div>

          <Separator />

          {/* Detailed Pallet Information */}
          <div className="space-y-3 text-sm">
            <div className="flex justify-between">
              <span className="text-neutral-600">Artikel-Nr:</span>
              <span className="font-medium">{pallet.articleNumber || 'Nicht angegeben'}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-neutral-600">Beschreibung:</span>
              <span className="font-medium text-right max-w-[180px] truncate" title={pallet.productDescription}>
                {pallet.productDescription || 'Keine Beschreibung'}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-neutral-600">Charge:</span>
              <span className="font-medium">{pallet.chargeNumber || 'Nicht angegeben'}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-neutral-600">Standort:</span>
              <span className="font-medium">{pallet.location || 'Nicht angegeben'}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-neutral-600">Kartons:</span>
              <span className="font-medium">{pallet.cartonCount || 0}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-neutral-600">Artikel/Karton:</span>
              <span className="font-medium">{pallet.itemsPerCarton || 0}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-neutral-600">Gesamt Artikel:</span>
              <span className="font-medium">{pallet.totalItems || 0}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-neutral-600">Erstellt:</span>
              <span className="font-medium">{new Date(pallet.createdAt).toLocaleDateString('de-DE')}</span>
            </div>
          </div>

          <Separator />

          {/* Action Buttons */}
          <div className="space-y-3">
            <div className="grid grid-cols-2 gap-3">
              <Button
                onClick={handleDownload}
                variant="outline"
                disabled={!pallet.qrCodeData}
                className="w-full"
              >
                <Download className="mr-2 h-4 w-4" />
                Download
              </Button>
              <Button
                onClick={handlePrint}
                variant="outline"
                disabled={!pallet.qrCodeData}
                className="w-full"
              >
                <Printer className="mr-2 h-4 w-4" />
                Drucken
              </Button>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <Button
                onClick={handleCopyCode}
                variant="secondary"
                className="w-full"
              >
                <Copy className="mr-2 h-4 w-4" />
                Code kopieren
              </Button>
              <Button
                onClick={() => regenerateQRMutation.mutate(pallet.id)}
                variant="secondary"
                disabled={regenerateQRMutation.isPending}
                className="w-full"
              >
                {regenerateQRMutation.isPending ? (
                  <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                ) : (
                  <RefreshCw className="mr-2 h-4 w-4" />
                )}
                QR erneuern
              </Button>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
