import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertPalletSchema, type InsertPallet } from "@shared/schema";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface CreatePalletModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function CreatePalletModal({ open, onOpenChange }: CreatePalletModalProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm<InsertPallet>({
    resolver: zodResolver(insertPalletSchema),
    defaultValues: {
      type: "",
      productionDate: "",
      packagingDate: "",
      expiryDate: "",
      status: "offen",
    },
  });

  const createMutation = useMutation({
    mutationFn: async (data: InsertPallet) => {
      const response = await apiRequest("POST", "/api/pallets", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/pallets"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
      toast({
        title: "Palette erfolgreich erstellt",
        description: "Die neue Palette wurde angelegt und der QR-Code generiert",
      });
      form.reset();
      onOpenChange(false);
    },
    onError: (error: any) => {
      toast({
        title: "Fehler beim Erstellen",
        description: error.message || "Unbekannter Fehler",
        variant: "destructive",
      });
    },
  });

  const onSubmit = async (data: InsertPallet) => {
    await createMutation.mutateAsync(data);
  };

  const handleClose = () => {
    form.reset();
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md w-full max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Neue Palette erstellen</DialogTitle>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <FormField
              control={form.control}
              name="type"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Produkttyp</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger className="text-lg py-3">
                        <SelectValue placeholder="Typ auswählen" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="Flammkuchen XL">Flammkuchen XL</SelectItem>
                      <SelectItem value="Flammkuchen L">Flammkuchen L</SelectItem>
                      <SelectItem value="Flammkuchen M">Flammkuchen M</SelectItem>
                      <SelectItem value="Flammkuchen S">Flammkuchen S</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="productionDate"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Produktionsdatum</FormLabel>
                  <FormControl>
                    <Input
                      {...field}
                      type="date"
                      className="text-lg py-3"
                      disabled={createMutation.isPending}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="packagingDate"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Verpackungsdatum</FormLabel>
                  <FormControl>
                    <Input
                      {...field}
                      type="date"
                      className="text-lg py-3"
                      disabled={createMutation.isPending}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="expiryDate"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>MHD (Mindesthaltbarkeitsdatum)</FormLabel>
                  <FormControl>
                    <Input
                      {...field}
                      type="date"
                      className="text-lg py-3"
                      disabled={createMutation.isPending}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="flex flex-col sm:flex-row gap-4 pt-4">
              <Button
                type="submit"
                className="flex-1 min-h-[48px]"
                disabled={createMutation.isPending}
              >
                {createMutation.isPending ? "Erstellen..." : "Palette erstellen"}
              </Button>

              <Button
                type="button"
                variant="secondary"
                onClick={handleClose}
                className="flex-1 min-h-[48px]"
                disabled={createMutation.isPending}
              >
                Abbrechen
              </Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
