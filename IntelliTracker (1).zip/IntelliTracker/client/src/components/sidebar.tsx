import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useQuery } from "@tanstack/react-query";
import { cn } from "@/lib/utils";
import type { Pallet } from "@shared/schema";
import { 
  Package, 
  Home, 
  Plus, 
  Archive, 
  Settings,
  LogOut,
  Menu,
  X,
  QrCode,
  FileText,
  CheckCircle,
  Download,
  AlertTriangle
} from "lucide-react";

interface SidebarProps {
  className?: string;
}

export function Sidebar({ className }: SidebarProps) {
  const [location] = useLocation();
  const { user, logout, isAdmin } = useAuth();
  const [isCollapsed, setIsCollapsed] = useState(false);

  // Fetch expiry alerts for critical count
  const { data: expiringPallets = [] } = useQuery<Pallet[]>({
    queryKey: ["/api/pallets/expiry-alerts"],
    enabled: !!user,
  });

  const getCriticalCount = () => {
    const today = new Date();
    return expiringPallets.filter(pallet => {
      const expiry = new Date(pallet.expiryDate);
      const diffTime = expiry.getTime() - today.getTime();
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      return diffDays <= 30; // Critical if expires within 30 days or already expired
    }).length;
  };

  const criticalCount = getCriticalCount();

  const handleLogout = async () => {
    try {
      await logout();
    } catch (error) {
      console.error("Logout error:", error);
    }
  };

  const navigationItems = [
    {
      title: "Dashboard",
      href: isAdmin ? "/admin" : "/dashboard",
      icon: Home,
      adminOnly: false,
    },
    {
      title: "Artikel verwalten",
      href: "/articles",
      icon: Archive,
      adminOnly: true,
    },
    {
      title: "Einstellungen",
      href: "/settings",
      icon: Settings,
      adminOnly: true,
    },
    {
      title: "QR Scanner",
      href: "/scanner",
      icon: QrCode,
      adminOnly: false,
      employeeOnly: true,
    },
    {
      title: "Abgeschlossene Paletten",
      href: "/completed-pallets",
      icon: CheckCircle,
      adminOnly: true,
    },
    {
      title: "Paletten Export",
      href: "/export-pallets",
      icon: Download,
      adminOnly: true,
    },
    {
      title: "MHD-Alarme",
      href: "/expiry-alerts",
      icon: AlertTriangle,
      adminOnly: false,
    },
  ];

  const filteredItems = navigationItems.filter(item => {
    if (item.adminOnly && !isAdmin) return false;
    if (item.employeeOnly && isAdmin) return false;
    return true;
  });

  return (
    <div className={cn(
      "flex flex-col h-screen bg-white border-r border-neutral-200 transition-all duration-300",
      isCollapsed ? "w-16" : "w-64",
      className
    )}>
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-neutral-200">
        {!isCollapsed && (
          <div className="flex items-center space-x-2">
            <Package className="text-primary text-xl" />
            <h1 className="font-semibold text-neutral-900 text-sm">Paletten Management</h1>
          </div>
        )}
        <Button
          variant="ghost"
          size="sm"
          onClick={() => setIsCollapsed(!isCollapsed)}
          className="p-2"
        >
          {isCollapsed ? <Menu className="h-4 w-4" /> : <X className="h-4 w-4" />}
        </Button>
      </div>

      {/* User Info */}
      <div className="p-4 border-b border-neutral-200">
        <div className={cn(
          "flex items-center space-x-3",
          isCollapsed && "justify-center"
        )}>
          <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center text-white text-sm font-medium">
            {user?.name.charAt(0).toUpperCase()}
          </div>
          {!isCollapsed && (
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-neutral-900 truncate">{user?.name}</p>
              <p className="text-xs text-neutral-500 capitalize">{user?.role}</p>
            </div>
          )}
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-4 space-y-2">
        {filteredItems.map((item) => {
          const Icon = item.icon;
          const isActive = location === item.href;
          const showBadge = item.href === "/expiry-alerts" && criticalCount > 0;
          
          return (
            <Link key={item.href} href={item.href}>
              <Button
                variant={isActive ? "default" : "ghost"}
                className={cn(
                  "w-full justify-start h-12 relative",
                  isCollapsed && "justify-center px-0",
                  isActive && "bg-primary text-white hover:bg-primary/90"
                )}
              >
                <Icon className={cn("h-5 w-5", !isCollapsed && "mr-3")} />
                {!isCollapsed && (
                  <div className="flex items-center justify-between w-full">
                    <span className="text-sm">{item.title}</span>
                    {showBadge && (
                      <Badge variant="destructive" className="ml-2 h-5 min-w-[20px] text-xs">
                        {criticalCount}
                      </Badge>
                    )}
                  </div>
                )}
                {isCollapsed && showBadge && (
                  <Badge variant="destructive" className="absolute -top-1 -right-1 h-5 w-5 rounded-full p-0 flex items-center justify-center text-xs">
                    {criticalCount > 9 ? "9+" : criticalCount}
                  </Badge>
                )}
              </Button>
            </Link>
          );
        })}
      </nav>

      {/* Footer */}
      <div className="p-4 border-t border-neutral-200">
        <Button
          variant="ghost"
          onClick={handleLogout}
          className={cn(
            "w-full justify-start h-12 text-neutral-600 hover:text-neutral-900",
            isCollapsed && "justify-center px-0"
          )}
        >
          <LogOut className={cn("h-5 w-5", !isCollapsed && "mr-3")} />
          {!isCollapsed && <span className="text-sm">Abmelden</span>}
        </Button>
      </div>
    </div>
  );
}