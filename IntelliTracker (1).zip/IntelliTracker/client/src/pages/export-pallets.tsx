import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Sidebar } from "@/components/sidebar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Download, FileText, Calendar, Package, Filter } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { formatDate, formatDateTime } from "@/lib/utils";
import { exportCompletedPalletsToPDF, exportSinglePalletToPDF, type PalletData } from "@/lib/pdf-export";
import { type Pallet } from "@shared/schema";

export default function ExportPalletsPage() {
  const { toast } = useToast();
  const [dateFilter, setDateFilter] = useState<string>("all");
  const [selectedPallets, setSelectedPallets] = useState<Set<number>>(new Set());
  const [selectAll, setSelectAll] = useState(false);

  const { data: allPallets, isLoading } = useQuery({
    queryKey: ["/api/pallets/completed"],
    queryFn: async () => {
      const response = await apiRequest("GET", "/api/pallets/completed");
      return response.json() as Promise<Pallet[]>;
    },
  });

  // Filter pallets based on date selection
  const filteredPallets = allPallets?.filter(pallet => {
    if (dateFilter === "all") return true;
    
    const palletDate = new Date(pallet.createdAt);
    const now = new Date();
    
    switch (dateFilter) {
      case "today":
        return palletDate.toDateString() === now.toDateString();
      case "yesterday":
        const yesterday = new Date(now);
        yesterday.setDate(yesterday.getDate() - 1);
        return palletDate.toDateString() === yesterday.toDateString();
      case "last7days":
        const weekAgo = new Date(now);
        weekAgo.setDate(weekAgo.getDate() - 7);
        return palletDate >= weekAgo;
      case "last30days":
        const monthAgo = new Date(now);
        monthAgo.setDate(monthAgo.getDate() - 30);
        return palletDate >= monthAgo;
      case "thisMonth":
        return palletDate.getMonth() === now.getMonth() && palletDate.getFullYear() === now.getFullYear();
      case "lastMonth":
        const lastMonth = new Date(now);
        lastMonth.setMonth(lastMonth.getMonth() - 1);
        return palletDate.getMonth() === lastMonth.getMonth() && palletDate.getFullYear() === lastMonth.getFullYear();
      default:
        return true;
    }
  }) || [];

  const handleSelectAll = (checked: boolean) => {
    setSelectAll(checked);
    if (checked) {
      setSelectedPallets(new Set(filteredPallets.map(p => p.id)));
    } else {
      setSelectedPallets(new Set());
    }
  };

  const handleSelectPallet = (palletId: number, checked: boolean) => {
    const newSelected = new Set(selectedPallets);
    if (checked) {
      newSelected.add(palletId);
    } else {
      newSelected.delete(palletId);
    }
    setSelectedPallets(newSelected);
    setSelectAll(newSelected.size === filteredPallets.length);
  };

  const getSelectedPallets = () => {
    return filteredPallets.filter(p => selectedPallets.has(p.id));
  };

  const handleExportSelected = () => {
    const selected = getSelectedPallets();
    if (selected.length === 0) {
      toast({
        title: "Keine Paletten ausgewählt",
        description: "Bitte wählen Sie mindestens eine Palette aus",
        variant: "destructive",
      });
      return;
    }

    try {
      const filterLabel = getFilterLabel(dateFilter);
      exportCompletedPalletsToPDF(selected, `Abgeschlossene Paletten - ${filterLabel}`);
      toast({
        title: "Export erfolgreich",
        description: `${selected.length} Paletten wurden als PDF exportiert`,
      });
    } catch (error) {
      toast({
        title: "Export fehlgeschlagen",
        description: "Fehler beim Erstellen des PDF-Exports",
        variant: "destructive",
      });
    }
  };

  const handleExportAll = () => {
    if (filteredPallets.length === 0) {
      toast({
        title: "Keine Paletten verfügbar",
        description: "Es sind keine Paletten für den gewählten Zeitraum vorhanden",
        variant: "destructive",
      });
      return;
    }

    try {
      const filterLabel = getFilterLabel(dateFilter);
      exportCompletedPalletsToPDF(filteredPallets, `Abgeschlossene Paletten - ${filterLabel}`);
      toast({
        title: "Export erfolgreich",
        description: `${filteredPallets.length} Paletten wurden als PDF exportiert`,
      });
    } catch (error) {
      toast({
        title: "Export fehlgeschlagen",
        description: "Fehler beim Erstellen des PDF-Exports",
        variant: "destructive",
      });
    }
  };

  const handleExportSingle = (pallet: Pallet) => {
    try {
      exportSinglePalletToPDF(pallet);
      toast({
        title: "Export erfolgreich",
        description: `Palette ${pallet.palletNumber} wurde als PDF exportiert`,
      });
    } catch (error) {
      toast({
        title: "Export fehlgeschlagen",
        description: "Fehler beim Erstellen des PDF-Exports",
        variant: "destructive",
      });
    }
  };

  const getFilterLabel = (filter: string): string => {
    switch (filter) {
      case "all": return "Alle";
      case "today": return "Heute";
      case "yesterday": return "Gestern";
      case "last7days": return "Letzte 7 Tage";
      case "last30days": return "Letzte 30 Tage";
      case "thisMonth": return "Diesen Monat";
      case "lastMonth": return "Letzten Monat";
      default: return "Alle";
    }
  };

  const getLocationBadge = (location: string | null) => {
    if (!location) {
      return <Badge variant="outline">Nicht zugewiesen</Badge>;
    }

    const variants: Record<string, any> = {
      kühlhaus: "secondary",
      tiefkühler: "default",
      versandt: "success",
    };

    const labels: Record<string, string> = {
      kühlhaus: "Kühlhaus",
      tiefkühler: "Tiefkühler",
      versandt: "Versandt",
    };

    return (
      <Badge variant={variants[location] || "outline"}>
        {labels[location] || location}
      </Badge>
    );
  };

  return (
    <div className="flex h-screen bg-neutral-50">
      <Sidebar />
      
      <main className="flex-1 overflow-auto">
        <div className="max-w-7xl mx-auto p-6 space-y-6">
          {/* Header */}
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <FileText className="text-primary text-2xl" />
              <div>
                <h1 className="text-2xl font-semibold text-neutral-900">Paletten Export</h1>
                <p className="text-neutral-600">Exportieren Sie abgeschlossene Paletten als PDF</p>
              </div>
            </div>
          </div>

          {/* Filter Controls */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Filter className="h-5 w-5" />
                Filter & Export Optionen
              </CardTitle>
            </CardHeader>
            
            <CardContent>
              <div className="flex flex-wrap gap-4 items-center">
                <div className="flex items-center gap-2">
                  <Calendar className="h-4 w-4 text-neutral-500" />
                  <Select value={dateFilter} onValueChange={setDateFilter}>
                    <SelectTrigger className="w-48">
                      <SelectValue placeholder="Zeitraum wählen" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Alle</SelectItem>
                      <SelectItem value="today">Heute</SelectItem>
                      <SelectItem value="yesterday">Gestern</SelectItem>
                      <SelectItem value="last7days">Letzte 7 Tage</SelectItem>
                      <SelectItem value="last30days">Letzte 30 Tage</SelectItem>
                      <SelectItem value="thisMonth">Diesen Monat</SelectItem>
                      <SelectItem value="lastMonth">Letzten Monat</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="flex gap-2">
                  <Button
                    onClick={handleExportAll}
                    disabled={filteredPallets.length === 0}
                    className="bg-primary hover:bg-primary-dark"
                  >
                    <Download className="mr-2 h-4 w-4" />
                    Alle exportieren ({filteredPallets.length})
                  </Button>

                  <Button
                    onClick={handleExportSelected}
                    disabled={selectedPallets.size === 0}
                    variant="outline"
                  >
                    <Download className="mr-2 h-4 w-4" />
                    Ausgewählte exportieren ({selectedPallets.size})
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Statistics */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-neutral-600">Gefilterte Paletten</p>
                    <p className="text-3xl font-semibold text-primary">
                      {isLoading ? "..." : filteredPallets.length}
                    </p>
                  </div>
                  <Package className="text-primary text-2xl" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-neutral-600">Ausgewählt</p>
                    <p className="text-3xl font-semibold text-secondary">
                      {selectedPallets.size}
                    </p>
                  </div>
                  <Checkbox 
                    checked={selectAll}
                    onCheckedChange={handleSelectAll}
                    className="h-6 w-6"
                  />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-neutral-600">Gesamtanzahl</p>
                    <p className="text-3xl font-semibold text-neutral-800">
                      {isLoading ? "..." : allPallets?.length || 0}
                    </p>
                  </div>
                  <FileText className="text-neutral-600 text-2xl" />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Pallets Table */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>
                  Paletten - {getFilterLabel(dateFilter)}
                </CardTitle>
                
                <div className="flex items-center gap-2">
                  <Checkbox
                    checked={selectAll}
                    onCheckedChange={handleSelectAll}
                  />
                  <span className="text-sm text-neutral-600">Alle auswählen</span>
                </div>
              </div>
            </CardHeader>
            
            <CardContent>
              {isLoading ? (
                <div className="text-center py-8">
                  <p className="text-neutral-500">Lädt Paletten...</p>
                </div>
              ) : filteredPallets.length === 0 ? (
                <div className="text-center py-8">
                  <Package className="mx-auto h-12 w-12 text-neutral-400 mb-4" />
                  <p className="text-neutral-500">
                    Keine Paletten für den gewählten Zeitraum vorhanden
                  </p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="bg-neutral-50">
                      <tr>
                        <th className="px-4 py-3 text-left">
                          <Checkbox
                            checked={selectAll}
                            onCheckedChange={handleSelectAll}
                          />
                        </th>
                        <th className="px-4 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                          Paletten-Nr.
                        </th>
                        <th className="px-4 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                          Produktbeschreibung
                        </th>
                        <th className="px-4 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                          Buchstabe
                        </th>
                        <th className="px-4 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                          MHD
                        </th>
                        <th className="px-4 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                          Gesamtstück
                        </th>
                        <th className="px-4 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                          Standort
                        </th>
                        <th className="px-4 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                          Abgeschlossen am
                        </th>
                        <th className="px-4 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                          Export
                        </th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-neutral-200">
                      {filteredPallets.map((pallet) => (
                        <tr key={pallet.id} className={selectedPallets.has(pallet.id) ? "bg-blue-50" : ""}>
                          <td className="px-4 py-4 whitespace-nowrap">
                            <Checkbox
                              checked={selectedPallets.has(pallet.id)}
                              onCheckedChange={(checked) => handleSelectPallet(pallet.id, checked as boolean)}
                            />
                          </td>
                          <td className="px-4 py-4 whitespace-nowrap text-sm font-mono text-neutral-900">
                            {pallet.palletNumber}
                          </td>
                          <td className="px-4 py-4 whitespace-nowrap text-sm text-neutral-900">
                            {pallet.productDescription}
                          </td>
                          <td className="px-4 py-4 whitespace-nowrap text-sm text-neutral-900">
                            {pallet.letterCode}
                          </td>
                          <td className="px-4 py-4 whitespace-nowrap text-sm text-neutral-900">
                            {pallet.expiryDate}
                          </td>
                          <td className="px-4 py-4 whitespace-nowrap text-sm text-neutral-900">
                            {pallet.totalItems} Stück
                          </td>
                          <td className="px-4 py-4 whitespace-nowrap">
                            {getLocationBadge(pallet.location)}
                          </td>
                          <td className="px-4 py-4 whitespace-nowrap text-sm text-neutral-500">
                            {formatDateTime(pallet.createdAt)}
                          </td>
                          <td className="px-4 py-4 whitespace-nowrap">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleExportSingle(pallet)}
                              className="text-primary hover:text-primary-dark"
                            >
                              <FileText className="h-4 w-4" />
                            </Button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}