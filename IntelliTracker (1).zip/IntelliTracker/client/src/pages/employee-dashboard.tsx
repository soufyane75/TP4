import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Sidebar } from "@/components/sidebar";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Camera, QrCode, Package, Edit, Clock, CheckCircle, RotateCcw, AlertTriangle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";
import { apiRequest } from "@/lib/queryClient";
import { formatDate } from "@/lib/utils";
import { type Pallet } from "@shared/schema";

export default function EmployeeDashboard() {
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();

  const { data: pallets, isLoading } = useQuery({
    queryKey: ["/api/pallets"],
    queryFn: async () => {
      const response = await apiRequest("GET", "/api/pallets");
      return response.json() as Promise<Pallet[]>;
    },
  });

  const { data: completedPallets, isLoading: isLoadingCompleted } = useQuery({
    queryKey: ["/api/pallets/completed"],
    queryFn: async () => {
      const response = await apiRequest("GET", "/api/pallets/completed");
      return response.json() as Promise<Pallet[]>;
    },
  });

  const { data: expiringPallets = [] } = useQuery<Pallet[]>({
    queryKey: ["/api/pallets/expiry-alerts"],
  });

  const getCriticalCount = () => {
    const today = new Date();
    return expiringPallets.filter(pallet => {
      const expiry = new Date(pallet.expiryDate);
      const diffTime = expiry.getTime() - today.getTime();
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      return diffDays <= 30;
    }).length;
  };

  const criticalCount = getCriticalCount();
  const openPallets = pallets?.filter(pallet => pallet.status === "offen") || [];

  const restorePalletMutation = useMutation({
    mutationFn: async (palletId: number) => {
      const response = await apiRequest("PATCH", `/api/pallets/${palletId}`, {
        status: "offen",
        location: null
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/pallets"] });
      queryClient.invalidateQueries({ queryKey: ["/api/pallets/completed"] });
      toast({
        title: "Palette wiederhergestellt",
        description: "Die Palette wurde erfolgreich zu 'offen' zurückgesetzt",
      });
    },
    onError: () => {
      toast({
        title: "Fehler",
        description: "Fehler beim Wiederherstellen der Palette",
        variant: "destructive",
      });
    }
  });

  const handleQRScan = () => {
    setLocation("/scanner");
  };

  const handleEditPallet = (palletNumber: string) => {
    setLocation(`/pallet/${palletNumber}`);
  };

  const handleRestorePallet = (pallet: Pallet) => {
    restorePalletMutation.mutate(pallet.id);
  };

  return (
    <div className="flex h-screen bg-neutral-50">
      <Sidebar />
      
      <main className="flex-1 overflow-auto">
        <div className="max-w-6xl mx-auto p-6 space-y-6">
          {/* Header */}
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Package className="text-primary text-2xl" />
              <div>
                <h1 className="text-2xl font-semibold text-neutral-900">Mitarbeiter Dashboard</h1>
                <p className="text-neutral-600">Bearbeiten Sie offene Paletten oder scannen Sie QR-Codes</p>
              </div>
            </div>
            
            <Button
              onClick={handleQRScan}
              className="bg-primary hover:bg-primary-dark"
              size="lg"
            >
              <Camera className="mr-2 h-5 w-5" />
              QR Scanner öffnen
            </Button>
          </div>

          {/* MHD Alert Banner */}
          {criticalCount > 0 && (
            <Card className="border-red-200 bg-red-50">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <AlertTriangle className="h-6 w-6 text-red-500" />
                    <div>
                      <p className="font-medium text-red-800">
                        {criticalCount} Produkt{criticalCount !== 1 ? 'e' : ''} mit kritischen MHD-Terminen
                      </p>
                      <p className="text-sm text-red-600">
                        Ablauf innerhalb der nächsten 30 Tage
                      </p>
                    </div>
                  </div>
                  <Button 
                    onClick={() => setLocation("/expiry-alerts")}
                    variant="outline"
                    className="border-red-300 text-red-700 hover:bg-red-100"
                  >
                    Alarme anzeigen
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Stats */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-neutral-600">Offene Paletten</p>
                    <p className="text-3xl font-semibold text-warning">
                      {isLoading ? "..." : openPallets.length}
                    </p>
                  </div>
                  <Clock className="text-warning text-2xl" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-neutral-600">Abgeschlossene Paletten</p>
                    <p className="text-3xl font-semibold text-success">
                      {isLoadingCompleted ? "..." : completedPallets?.length || 0}
                    </p>
                  </div>
                  <CheckCircle className="text-success text-2xl" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-neutral-600">Gesamt Paletten</p>
                    <p className="text-3xl font-semibold text-neutral-800">
                      {isLoading ? "..." : pallets?.length || 0}
                    </p>
                  </div>
                  <Package className="text-primary text-2xl" />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Open Pallets Table */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="h-5 w-5 text-warning" />
                Offene Paletten zum Abschließen
              </CardTitle>
            </CardHeader>
            
            <CardContent>
              {isLoading ? (
                <div className="text-center py-8">
                  <p className="text-neutral-500">Lädt Paletten...</p>
                </div>
              ) : openPallets.length === 0 ? (
                <div className="text-center py-8">
                  <Package className="mx-auto h-12 w-12 text-neutral-400 mb-4" />
                  <p className="text-neutral-500">Keine offenen Paletten vorhanden</p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="bg-neutral-50">
                      <tr>
                        <th className="px-4 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                          Paletten-Nr.
                        </th>
                        <th className="px-4 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                          Produktbeschreibung
                        </th>
                        <th className="px-4 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                          Buchstabe
                        </th>
                        <th className="px-4 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                          MHD
                        </th>
                        <th className="px-4 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                          Status
                        </th>
                        <th className="px-4 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                          Aktion
                        </th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-neutral-200">
                      {openPallets.map((pallet) => (
                        <tr key={pallet.id}>
                          <td className="px-4 py-4 whitespace-nowrap text-sm font-mono text-neutral-900">
                            {pallet.palletNumber}
                          </td>
                          <td className="px-4 py-4 whitespace-nowrap text-sm text-neutral-900">
                            {pallet.productDescription}
                          </td>
                          <td className="px-4 py-4 whitespace-nowrap text-sm text-neutral-900">
                            {pallet.letterCode}
                          </td>
                          <td className="px-4 py-4 whitespace-nowrap text-sm text-neutral-900">
                            {pallet.expiryDate}
                          </td>
                          <td className="px-4 py-4 whitespace-nowrap">
                            <Badge variant="secondary" className="bg-warning/10 text-warning">
                              Offen
                            </Badge>
                          </td>
                          <td className="px-4 py-4 whitespace-nowrap">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleEditPallet(pallet.palletNumber)}
                              className="text-primary hover:text-primary-dark"
                            >
                              <Edit className="h-4 w-4 mr-1" />
                              Bearbeiten
                            </Button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Completed Pallets Table */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <CheckCircle className="h-5 w-5 text-success" />
                Abgeschlossene Paletten - Korrektur möglich
              </CardTitle>
            </CardHeader>
            
            <CardContent>
              {isLoadingCompleted ? (
                <div className="text-center py-8">
                  <p className="text-neutral-500">Lädt abgeschlossene Paletten...</p>
                </div>
              ) : !completedPallets || completedPallets.length === 0 ? (
                <div className="text-center py-8">
                  <CheckCircle className="mx-auto h-12 w-12 text-neutral-400 mb-4" />
                  <p className="text-neutral-500">Keine abgeschlossenen Paletten vorhanden</p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="bg-neutral-50">
                      <tr>
                        <th className="px-4 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                          Paletten-Nr.
                        </th>
                        <th className="px-4 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                          Produktbeschreibung
                        </th>
                        <th className="px-4 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                          Buchstabe
                        </th>
                        <th className="px-4 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                          MHD
                        </th>
                        <th className="px-4 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                          Gesamtstück
                        </th>
                        <th className="px-4 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                          Standort
                        </th>
                        <th className="px-4 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                          Aktionen
                        </th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-neutral-200">
                      {completedPallets.map((pallet) => (
                        <tr key={pallet.id}>
                          <td className="px-4 py-4 whitespace-nowrap text-sm font-mono text-neutral-900">
                            {pallet.palletNumber}
                          </td>
                          <td className="px-4 py-4 whitespace-nowrap text-sm text-neutral-900">
                            {pallet.productDescription}
                          </td>
                          <td className="px-4 py-4 whitespace-nowrap text-sm text-neutral-900">
                            {pallet.letterCode}
                          </td>
                          <td className="px-4 py-4 whitespace-nowrap text-sm text-neutral-900">
                            {pallet.expiryDate}
                          </td>
                          <td className="px-4 py-4 whitespace-nowrap text-sm text-neutral-900">
                            {pallet.totalItems ? `${pallet.totalItems} Stück` : "N/A"}
                          </td>
                          <td className="px-4 py-4 whitespace-nowrap">
                            <Badge 
                              variant={pallet.location === "versandt" ? "default" : "secondary"}
                              className={
                                pallet.location === "versandt" 
                                  ? "bg-blue-100 text-blue-800" 
                                  : pallet.location === "tiefkühler"
                                  ? "bg-blue-50 text-blue-600"
                                  : "bg-green-50 text-green-600"
                              }
                            >
                              {pallet.location || "Nicht zugewiesen"}
                            </Badge>
                          </td>
                          <td className="px-4 py-4 whitespace-nowrap">
                            <div className="flex gap-2">
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => handleEditPallet(pallet.palletNumber)}
                                className="text-primary hover:text-primary-dark"
                              >
                                <Edit className="h-4 w-4 mr-1" />
                                Bearbeiten
                              </Button>
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => handleRestorePallet(pallet)}
                                disabled={restorePalletMutation.isPending}
                                className="text-warning hover:text-warning-dark"
                              >
                                <RotateCcw className="h-4 w-4 mr-1" />
                                Wiederherstellen
                              </Button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}
