import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { type Pallet } from '@shared/schema';
import { formatDate } from './utils';

export type PalletData = Pallet;

export function exportCompletedPalletsToPDF(pallets: PalletData[], title = 'Abgeschlossene Paletten') {
  const doc = new jsPDF();
  
  // Add title
  doc.setFontSize(20);
  doc.text(title, 20, 20);
  
  // Add export date
  doc.setFontSize(12);
  doc.text(`Exportiert am: ${formatDate(new Date())}`, 20, 30);
  
  // Prepare table data
  const tableData = pallets.map(pallet => [
    pallet.palletNumber,
    pallet.productDescription,
    pallet.letterCode,
    pallet.articleNumber,
    pallet.chargeNumber,
    pallet.expiryDate,
    pallet.cartonCount.toString(),
    pallet.itemsPerCarton.toString(),
    pallet.totalItems?.toString() || '0',
    getLocationText(pallet.location),
    formatDate(pallet.createdAt)
  ]);

  // Add table
  autoTable(doc, {
    head: [[
      'Paletten-Nr.',
      'Produktbeschreibung',
      'Buchstabe',
      'Artikelnummer',
      'Charge',
      'MHD',
      'Kartons',
      'Stück/Karton',
      'Gesamtstück',
      'Standort',
      'Abgeschlossen am'
    ]],
    body: tableData,
    startY: 40,
    styles: { fontSize: 8 },
    headStyles: { fillColor: [66, 139, 202] },
    alternateRowStyles: { fillColor: [245, 245, 245] },
    margin: { top: 40 },
  });

  // Add summary
  const finalY = (doc as any).lastAutoTable.finalY || 40;
  doc.setFontSize(12);
  doc.text(`Gesamtanzahl Paletten: ${pallets.length}`, 20, finalY + 20);

  // Calculate totals
  const totalItems = pallets.reduce((sum, pallet) => sum + (pallet.totalItems || 0), 0);
  doc.text(`Gesamtanzahl Stück: ${totalItems}`, 20, finalY + 30);

  // Location summary
  const locationCounts = pallets.reduce((acc, pallet) => {
    const location = pallet.location || 'Nicht zugewiesen';
    acc[location] = (acc[location] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  let yPos = finalY + 45;
  doc.text('Standort-Übersicht:', 20, yPos);
  Object.entries(locationCounts).forEach(([location, count]) => {
    yPos += 10;
    doc.text(`${getLocationText(location)}: ${count} Paletten`, 30, yPos);
  });

  // Generate filename with timestamp
  const timestamp = new Date().toISOString().slice(0, 19).replace(/:/g, '-');
  const filename = `Abgeschlossene_Paletten_${timestamp}.pdf`;

  // Save the PDF
  doc.save(filename);
}

export function exportSinglePalletToPDF(pallet: PalletData) {
  const doc = new jsPDF();
  
  // Add title
  doc.setFontSize(20);
  doc.text(`Palette ${pallet.palletNumber}`, 20, 20);
  
  // Add export date
  doc.setFontSize(12);
  doc.text(`Exportiert am: ${formatDate(new Date())}`, 20, 30);
  
  // Pallet details
  const details = [
    ['Paletten-Nummer:', pallet.palletNumber],
    ['Produktbeschreibung:', pallet.productDescription],
    ['Buchstabe:', pallet.letterCode],
    ['Artikelnummer:', pallet.articleNumber],
    ['Chargennummer:', pallet.chargeNumber],
    ['MHD:', pallet.expiryDate],
    ['Anzahl Kartons:', pallet.cartonCount.toString()],
    ['Stück pro Karton:', pallet.itemsPerCarton.toString()],
    ['Gesamtstück:', pallet.totalItems?.toString() || '0'],
    ['Status:', pallet.status],
    ['Standort:', getLocationText(pallet.location)],
    ['Abgeschlossen am:', formatDate(pallet.createdAt)]
  ];

  // Add details table
  autoTable(doc, {
    body: details,
    startY: 40,
    styles: { fontSize: 12 },
    columnStyles: {
      0: { fontStyle: 'bold', cellWidth: 50 },
      1: { cellWidth: 100 }
    },
    theme: 'plain'
  });

  // Generate filename
  const filename = `Palette_${pallet.palletNumber}.pdf`;
  
  // Save the PDF
  doc.save(filename);
}

function getLocationText(location: string | null | undefined): string {
  switch (location) {
    case 'kühlhaus':
      return 'Kühlhaus';
    case 'tiefkühler':
      return 'Tiefkühler';
    case 'versandt':
      return 'Versandt';
    default:
      return 'Nicht zugewiesen';
  }
}